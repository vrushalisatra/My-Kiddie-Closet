@echo off
title My Kiddie Closet Store Server
cd /d "%~dp0"
set "PATH=C:\Users\hp\.gemini\antigravity\bin\node;%PATH%"

echo ============================================================
echo   My Kiddie Closet - E-Commerce Web Server
echo   "Little Looks for Big Imaginations"
echo ============================================================
echo.
echo Store URL:   http://localhost:5000
echo Admin URL:   http://localhost:5000/admin
echo Admin Login: admin@mykiddiecloset.com / Admin@123
echo.
echo Launching your browser in 2 seconds...
start "" "http://localhost:5000"
echo Server is running. Keep this window open while using the site!
echo Press Ctrl+C to stop the server anytime.
echo.
node server.js
pause