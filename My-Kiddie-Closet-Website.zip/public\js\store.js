/**
 * My Kiddie Closet - Central Client Store & State Management
 */

const Store = {
  // State
  user: null,
  cart: [],
  wishlist: [],
  listeners: [],

  init() {
    this.loadLocalCart();
    this.loadLocalWishlist();
    this.checkSession();
  },

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  },

  notify(event, data) {
    this.listeners.forEach(fn => {
      try { fn(event, data); } catch (e) { console.error('Listener error:', e); }
    });
    this.updateBadges();
  },

  // User Authentication
  async checkSession() {
    const token = API.getToken();
    if (!token) {
      this.user = null;
      this.notify('user_changed', null);
      return;
    }

    try {
      const res = await API.auth.me();
      this.user = res.user;
      this.notify('user_changed', this.user);
      this.syncWishlistOnLogin();
    } catch (err) {
      this.user = null;
      API.setToken('');
      this.notify('user_changed', null);
    }
  },

  setUser(user, token) {
    this.user = user;
    if (token) API.setToken(token);
    this.notify('user_changed', user);
    if (user) {
      this.syncWishlistOnLogin();
    }
  },

  logout() {
    this.user = null;
    API.setToken('');
    this.notify('user_changed', null);
    this.showToast('You have logged out. See you soon!', 'blue');
    if (window.location.pathname.includes('admin') || window.location.pathname.includes('account')) {
      setTimeout(() => { window.location.href = '/'; }, 500);
    }
  },

  // Cart Management
  loadLocalCart() {
    try {
      const raw = localStorage.getItem('mkc_cart');
      this.cart = raw ? JSON.parse(raw) : [];
    } catch (e) {
      this.cart = [];
    }
    this.updateBadges();
  },

  saveCart() {
    localStorage.setItem('mkc_cart', JSON.stringify(this.cart));
    this.notify('cart_changed', this.cart);
  },

  addToCart(item, openDrawer = true) {
    // Unique key: productId + size + color
    const existingIndex = this.cart.findIndex(i =>
      i.productId === item.productId &&
      i.size === item.size &&
      i.color === item.color
    );

    const qtyToAdd = parseInt(item.quantity, 10) || 1;

    if (existingIndex > -1) {
      this.cart[existingIndex].quantity += qtyToAdd;
    } else {
      this.cart.push({
        productId: item.productId,
        name: item.name,
        price: item.price,
        image: item.image,
        size: item.size || '0-3M',
        color: item.color || 'Baby Pink',
        quantity: qtyToAdd,
        slug: item.slug || ''
      });
    }

    this.saveCart();
    this.showToast(`Added "${item.name}" to cart! 🛍️`, 'success');

    if (openDrawer) {
      this.openCartDrawer();
    }
  },

  updateCartQuantity(index, newQty) {
    if (index >= 0 && index < this.cart.length) {
      const qty = parseInt(newQty, 10);
      if (qty <= 0) {
        this.cart.splice(index, 1);
        this.showToast('Item removed from cart', 'blue');
      } else {
        this.cart[index].quantity = qty;
      }
      this.saveCart();
    }
  },

  removeFromCart(index) {
    if (index >= 0 && index < this.cart.length) {
      this.cart.splice(index, 1);
      this.saveCart();
      this.showToast('Item removed from cart', 'blue');
    }
  },

  clearCart() {
    this.cart = [];
    this.saveCart();
  },

  getCartCount() {
    return this.cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  },

  getCartSubtotal() {
    return this.cart.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);
  },

  // Wishlist Management
  loadLocalWishlist() {
    try {
      const raw = localStorage.getItem('mkc_wishlist');
      this.wishlist = raw ? JSON.parse(raw) : [];
    } catch (e) {
      this.wishlist = [];
    }
    this.updateBadges();
  },

  saveWishlist() {
    localStorage.setItem('mkc_wishlist', JSON.stringify(this.wishlist));
    this.notify('wishlist_changed', this.wishlist);
  },

  async toggleWishlist(productId) {
    const idx = this.wishlist.indexOf(productId);
    let added = false;

    if (idx > -1) {
      this.wishlist.splice(idx, 1);
      this.showToast('Removed from Wishlist', 'blue');
    } else {
      this.wishlist.push(productId);
      this.showToast('Added to your Wishlist! 💖', 'pink');
      added = true;
    }

    this.saveWishlist();

    // If logged in, sync with server
    if (this.user) {
      try {
        await API.wishlist.toggle(productId);
      } catch (e) {
        console.warn('Could not sync wishlist with server:', e);
      }
    }

    return added;
  },

  isWishlisted(productId) {
    return this.wishlist.includes(productId);
  },

  async syncWishlistOnLogin() {
    try {
      const res = await API.wishlist.get();
      if (res && res.productIds) {
        const merged = Array.from(new Set([...this.wishlist, ...res.productIds]));
        this.wishlist = merged;
        this.saveWishlist();
        await API.wishlist.sync(this.wishlist);
      }
    } catch (err) {
      console.warn('Wishlist sync error:', err);
    }
  },

  // Badge Counters
  updateBadges() {
    const cartBadges = document.querySelectorAll('.cart-badge-count');
    const cartCount = this.getCartCount();
    cartBadges.forEach(b => {
      b.textContent = cartCount;
      b.style.display = cartCount > 0 ? 'inline-flex' : 'none';
    });

    const wishlistBadges = document.querySelectorAll('.wishlist-badge-count');
    const wishCount = this.wishlist.length;
    wishlistBadges.forEach(b => {
      b.textContent = wishCount;
      b.style.display = wishCount > 0 ? 'inline-flex' : 'none';
    });

    // Update account buttons
    const userPills = document.querySelectorAll('.user-account-pill');
    userPills.forEach(p => {
      if (this.user) {
        p.innerHTML = `
          <a href="/account" class="flex items-center gap-2 text-sm font-semibold text-slate-700 hover:text-pink-600 transition">
            <span class="w-8 h-8 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-xs uppercase shadow-sm">
              ${this.user.name.charAt(0)}
            </span>
            <span class="hidden lg:inline">${this.user.name.split(' ')[0]}</span>
          </a>
        `;
      } else {
        p.innerHTML = `
          <a href="/account" class="flex items-center gap-2 text-sm font-semibold text-slate-700 hover:text-pink-600 transition">
            <svg class="w-6 h-6 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
            <span class="hidden lg:inline">Sign In</span>
          </a>
        `;
      }
    });
  },

  // Cart Drawer UI Trigger
  openCartDrawer() {
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer && overlay) {
      drawer.classList.add('open');
      overlay.classList.add('open');
      this.renderCartDrawerItems();
    }
  },

  closeCartDrawer() {
    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');
    if (drawer && overlay) {
      drawer.classList.remove('open');
      overlay.classList.remove('open');
    }
  },

  renderCartDrawerItems() {
    const container = document.getElementById('drawer-items-list');
    const subtotalEl = document.getElementById('drawer-subtotal');
    const shippingProgressEl = document.getElementById('drawer-shipping-progress');
    const shippingTextEl = document.getElementById('drawer-shipping-text');
    const checkoutBtn = document.getElementById('drawer-checkout-btn');

    if (!container) return;

    const subtotal = this.getCartSubtotal();
    if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toLocaleString('en-IN')}`;

    const freeThreshold = 999;
    const remaining = Math.max(0, freeThreshold - subtotal);
    const progressPercent = Math.min(100, Math.round((subtotal / freeThreshold) * 100));

    if (shippingProgressEl) shippingProgressEl.style.width = `${progressPercent}%`;
    if (shippingTextEl) {
      if (subtotal === 0) {
        shippingTextEl.innerHTML = `Shop for <b>₹999</b> to unlock <b>FREE Express Shipping</b>! 🚚`;
      } else if (remaining === 0) {
        shippingTextEl.innerHTML = `🎉 <b>Congratulations!</b> You've unlocked FREE Shipping!`;
      } else {
        shippingTextEl.innerHTML = `Add <b>₹${remaining.toLocaleString('en-IN')}</b> more for <b>FREE Shipping</b>!`;
      }
    }

    if (this.cart.length === 0) {
      container.innerHTML = `
        <div class="py-16 text-center text-slate-500">
          <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-pink-50 flex items-center justify-center text-3xl">🧸</div>
          <p class="font-bold text-lg text-slate-700 mb-1">Your closet is empty!</p>
          <p class="text-sm text-slate-500 mb-6">Discover delightful outfits for your little angel.</p>
          <a href="/shop" onclick="Store.closeCartDrawer()" class="btn-primary inline-flex text-sm">Explore Collections</a>
        </div>
      `;
      if (checkoutBtn) checkoutBtn.classList.add('opacity-50', 'pointer-events-none');
      return;
    }

    if (checkoutBtn) checkoutBtn.classList.remove('opacity-50', 'pointer-events-none');

    container.innerHTML = this.cart.map((item, idx) => `
      <div class="flex gap-4 p-3 bg-white rounded-xl border border-slate-100 hover:border-pink-200 transition">
        <img src="${item.image}" alt="${item.name}" class="w-16 h-20 object-cover rounded-lg flex-shrink-0 bg-slate-50">
        <div class="flex-1 min-w-0">
          <h4 class="text-sm font-bold text-slate-800 truncate mb-1">${item.name}</h4>
          <p class="text-xs text-slate-500 mb-2">Size: <span class="font-semibold text-slate-700">${item.size}</span> | Color: <span class="font-semibold text-slate-700">${item.color}</span></p>
          <div class="flex items-center justify-between">
            <div class="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
              <button onclick="Store.updateCartQuantity(${idx}, ${item.quantity - 1})" class="px-2 py-1 text-slate-600 hover:bg-slate-200 text-xs font-bold transition">-</button>
              <span class="px-3 py-1 text-xs font-bold text-slate-800">${item.quantity}</span>
              <button onclick="Store.updateCartQuantity(${idx}, ${item.quantity + 1})" class="px-2 py-1 text-slate-600 hover:bg-slate-200 text-xs font-bold transition">+</button>
            </div>
            <div class="text-right">
              <span class="text-sm font-bold text-pink-600">₹${(item.price * item.quantity).toLocaleString('en-IN')}</span>
              <button onclick="Store.removeFromCart(${idx})" class="block text-[11px] text-slate-400 hover:text-red-500 transition mt-0.5">Remove</button>
            </div>
          </div>
        </div>
      </div>
    `).join('');
  },

  // Toast Notification
  showToast(message, type = 'pink') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `kiddie-toast ${type}`;
    toast.innerHTML = `
      <span>${message}</span>
      <button onclick="this.parentElement.remove()" class="ml-auto text-slate-400 hover:text-slate-600 text-lg leading-none">&times;</button>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
};

window.Store = Store;
document.addEventListener('DOMContentLoaded', () => Store.init());
