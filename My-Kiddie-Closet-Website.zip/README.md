# 🧸 My Kiddie Closet — Production-Ready E-Commerce Platform

> **"Little Looks for Big Imaginations"**  
> Premium children's clothing brand e-commerce platform built for parents shopping for newborns, babies, toddlers, and young children.

---

## 🎨 Brand Identity

- **Brand Name**: My Kiddie Closet
- **Tagline**: *Little Looks for Big Imaginations*
- **Primary Colors**:
  - **Baby Pink**: `#FFD1DC` / `#F8BBD0` / Accent: `#FF6584`
  - **Baby Blue**: `#89CFF0` / `#BAE6FD` / Accent: `#0288D1`
- **Mascot**: Joyful smiling baby elephant (`/images/branding/mascot.png`)
- **Typography**: Google Fonts *Quicksand* (playful, rounded headings) and *Poppins* (clean, modern body)
- **Target Audience**: Indian & global parents shopping for newborns (0-6M), infants (6-12M), toddlers (1-3Y), and kids (3-8Y).

---

## ✨ Features Implemented

1. **Supplied Brand Mascot & Pastels**: Beautifully integrated smiling baby elephant logo, cloud gradients, and pastel pink/blue UI accents across all screens.
2. **Premium Kidswear Homepage**: Top promotional announcement bar, responsive sticky header, animated hero section with trust metrics, milestone collection cards, quick age selector, trending outfits grid, parent testimonials, and newsletter club signup.
3. **Boys, Girls & Baby/Toddler Collections**: Dedicated showcase pages and filtered catalog views with custom banners and lookbooks.
4. **Rich Product Detail Pages**: Multi-photo interactive gallery, price with MRP and discount percentage, size selector with real-time stock availability, color swatches, interactive **Size Guide modal** (with weights and heights), pincode delivery estimator, fabric & care tabs, and verified parent reviews.
5. **Functional Cart & Checkout**: Slide-out cart drawer, dedicated cart page, free shipping meter (unlocks at ₹999), promo coupon validation engine, and multi-step Indian checkout with complete address capture.
6. **Customer Registration & Login**: Secure password hashing with bcrypt, JWT authentication, user profile management, and saved delivery addresses.
7. **Wishlist Functionality**: Save favorite outfits with a single click; seamlessly moves to cart; persists in database for registered users and localStorage for guests.
8. **Faceted Filtering & Search**: Instant filtering by Age Group, Size, Brand Colour, Price Range, Category, and Collection, plus live search preview.
9. **Visual Order Tracking & Order History**: Live multi-milestone stepper (Placed &rarr; Packed &rarr; Shipped &rarr; In Transit &rarr; Out for Delivery &rarr; Delivered), courier partner details (Delhivery / BlueDart), and printable tax invoice.
10. **Comprehensive Admin Dashboard (`/admin`)**: Real-time sales KPIs, product catalog management (Add/Edit/Delete), quick inventory editor, order fulfillment and tracking number assigner, and customer directory.
11. **Razorpay Indian Payment Gateway**: Native Razorpay checkout support (`checkout.js`) with signature verification and an automatic test simulator for zero-friction local testing. Supports UPI (Google Pay, PhonePe, Paytm), RuPay, Cards, NetBanking, and Cash on Delivery (COD).
12. **SEO & Mobile Responsive**: Open Graph meta tags, Schema.org e-commerce structured data, XML sitemap, `robots.txt`, and mobile bottom navigation.
13. **Policy & Information Pages**: Shipping Policy, Returns & Refund Policy (15-day doorstep returns), Privacy Policy, Terms & Conditions, and Parent Care Contact with direct WhatsApp chat.
14. **Persistent Database**: File-based ACID-like atomic transactional database with automatic seeding of products, coupons, and orders.

---

## 🚀 Quickstart & Running Locally

### 1. Prerequisites
- **Node.js** v18+ (Node.js v20 LTS is pre-configured in `C:\Users\hp\.gemini\antigravity\bin\node`)

### 2. Start the Server
```bash
cd "C:\Users\hp\.gemini\antigravity\scratch\my-kiddie-closet"
node server.js
```

The application will start immediately at:
👉 **http://localhost:5000**

---

## 🔑 Demo & Test Credentials

| Role | Email | Password | Access |
|---|---|---|---|
| **Store Administrator** | `admin@mykiddiecloset.com` | `admin123` | [Admin Center](http://localhost:5000/admin) |
| **Demo Parent Customer** | `priya@example.com` | `parent123` | [Customer Account](http://localhost:5000/account) |

> *Tip: The login and admin pages include **1-Click Fill** buttons for effortless testing.*

---

## 🎟️ Active Promo Coupons

| Coupon Code | Discount | Minimum Order | Description |
|---|---|---|---|
| `LITTLE10` | 10% Off | ₹499 | Storewide discount for parents |
| `WELCOME15` | 15% Off | ₹999 | Welcome gift for new parents |
| `FREESHIP` | 100% Free Shipping | ₹0 | Free express shipping anywhere in India |
| `KIDDIE500` | Flat ₹500 Off | ₹2,499 | Big family order discount |

---

## 💳 Razorpay Indian Payments Configuration

The project is pre-configured with a **smart test mode payment simulator**. To connect your live Razorpay merchant account:

1. Sign up / Log in to [Razorpay Dashboard](https://dashboard.razorpay.com).
2. Navigate to **Account & Settings &rarr; API Keys**.
3. Generate your **Key ID** (`rzp_live_...` or `rzp_test_...`) and **Key Secret**.
4. Update `.env` (or update via the Admin Settings tab):
   ```env
   RAZORPAY_KEY_ID=rzp_live_your_actual_key_id
   RAZORPAY_KEY_SECRET=your_actual_key_secret
   RAZORPAY_MOCK_MODE=false
   ```
5. Restart the server.

---

## 📁 Project Structure

```
my-kiddie-closet/
├── .env                  # Environment secrets & Razorpay keys
├── .env.example          # Template configuration
├── package.json          # Node dependencies
├── server.js             # Express server & routing
├── src/
│   ├── config/           # Port, JWT & Razorpay config
│   ├── db/
│   │   ├── database.js   # File-based persistent DB engine
│   │   ├── seed.js       # Initial catalog & demo users
│   │   └── data/         # Persistent JSON databases
│   ├── middleware/       # Auth & Role verification
│   ├── routes/           # REST APIs (products, orders, payments, admin)
│   └── services/         # Razorpay & order fulfillment services
└── public/
    ├── index.html        # Premium Homepage
    ├── shop.html         # Catalog with faceted filters
    ├── collections.html  # Boys, Girls & Baby lookbooks
    ├── product.html      # Product detail, size guide & reviews
    ├── cart.html         # Shopping bag with free shipping meter
    ├── checkout.html     # Multi-step checkout with Razorpay & COD
    ├── order-confirmation.html # Order success with confetti
    ├── track-order.html  # Real-time visual package tracking
    ├── wishlist.html     # Customer saved outfits
    ├── account.html      # Customer portal & order history
    ├── admin.html        # Comprehensive admin dashboard
    ├── shipping-policy.html
    ├── refund-return-policy.html
    ├── privacy-policy.html
    ├── terms-conditions.html
    ├── size-guide.html
    ├── contact.html
    ├── sitemap.xml & robots.txt
    ├── css/styles.css    # Baby Pink & Baby Blue theme
    ├── js/               # Modular vanilla JS & store
    └── images/branding/  # Mascot & logo assets
```
