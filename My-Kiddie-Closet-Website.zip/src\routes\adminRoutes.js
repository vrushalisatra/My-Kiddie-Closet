const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { requireAdmin } = require('../middleware/auth');
const orderService = require('../services/orderService');

// All routes here require admin access
router.use(requireAdmin);

// GET /api/admin/stats - KPI summary
router.get('/stats', (req, res) => {
  try {
    const orders = db.orders.find();
    const products = db.products.find();
    const users = db.users.find({ role: 'customer' });

    // Revenue from paid or delivered orders
    const totalRevenue = orders
      .filter(o => o.paymentStatus === 'Paid' || o.status === 'Delivered')
      .reduce((sum, o) => sum + (o.total || 0), 0);

    const pendingOrders = orders.filter(o => ['Placed', 'Payment Pending', 'Confirmed'].includes(o.status)).length;
    const lowStockProducts = products.filter(p => (p.stockQuantity || 0) <= 5);

    // Recent orders
    const recentOrders = [...orders]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 8);

    // Category product counts
    const categoryCounts = {};
    products.forEach(p => {
      const cat = p.category || 'General';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    });

    res.json({
      success: true,
      stats: {
        totalRevenue,
        totalOrders: orders.length,
        totalCustomers: users.length,
        pendingOrders,
        lowStockCount: lowStockProducts.length,
        lowStockProducts: lowStockProducts.map(p => ({
          id: p.id,
          name: p.name,
          stock: p.stockQuantity,
          collection: p.collection
        })),
        recentOrders,
        categoryCounts
      }
    });
  } catch (err) {
    console.error('Admin stats error:', err);
    res.status(500).json({ success: false, message: 'Failed to compute admin statistics.' });
  }
});

// GET /api/admin/products - List all products with admin view
router.get('/products', (req, res) => {
  try {
    const products = db.products.find().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ success: true, products });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve products.' });
  }
});

// POST /api/admin/products - Create a new product
router.post('/products', (req, res) => {
  try {
    const {
      name,
      tagline,
      description,
      collection,
      category,
      ageGroup,
      price,
      originalPrice,
      images = [],
      sizes = [],
      colors = [],
      stockQuantity = 20,
      featured = false,
      bestseller = false,
      isNew = true,
      fabric,
      careInstructions
    } = req.body;

    if (!name || !collection || !category || !price) {
      return res.status(400).json({ success: false, message: 'Product name, collection, category, and price are required.' });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const numPrice = Number(price);
    const numOriginal = Number(originalPrice) || Math.round(numPrice * 1.35);
    const discountPercent = Math.round(((numOriginal - numPrice) / numOriginal) * 100);

    const newProduct = db.products.insert({
      name: name.trim(),
      slug: `${slug}-${Date.now().toString(36)}`,
      tagline: tagline || 'Crafted with love for gentle comfort',
      description: description || 'Premium children clothing piece crafted with pure organic fabrics and playful design.',
      collection,
      category,
      ageGroup: ageGroup || '0-6M',
      price: numPrice,
      originalPrice: numOriginal,
      discountPercent: Math.max(0, discountPercent),
      images: images.length ? images : ['https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80'],
      sizes: sizes.length ? sizes : [
        { size: '0-3M', stock: 5 },
        { size: '3-6M', stock: 5 },
        { size: '6-12M', stock: 5 }
      ],
      colors: colors.length ? colors : [
        { name: 'Baby Pink', hex: '#FAD2E1' },
        { name: 'Baby Blue', hex: '#C5DFF8' }
      ],
      stockQuantity: Number(stockQuantity) || 15,
      inStock: (Number(stockQuantity) || 15) > 0,
      featured: Boolean(featured),
      bestseller: Boolean(bestseller),
      isNew: Boolean(isNew),
      rating: 5.0,
      reviewCount: 1,
      fabric: fabric || '100% GOTS Certified Organic Cotton',
      careInstructions: careInstructions || 'Delicate wash cold (30°C). Do not bleach.',
      sku: `MKC-${collection.toUpperCase().substring(0, 2)}-${Math.floor(100 + Math.random() * 900)}`
    });

    res.status(201).json({ success: true, message: 'Product created successfully!', product: newProduct });
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ success: false, message: 'Failed to create product.' });
  }
});

// PUT /api/admin/products/:id - Update product
router.put('/products/:id', (req, res) => {
  try {
    const existing = db.products.findById(req.params.id);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const updates = { ...req.body };
    delete updates.id;

    if (updates.price) updates.price = Number(updates.price);
    if (updates.originalPrice) updates.originalPrice = Number(updates.originalPrice);
    if (updates.stockQuantity !== undefined) {
      updates.stockQuantity = Number(updates.stockQuantity);
      updates.inStock = updates.stockQuantity > 0;
    }

    const updated = db.products.update(existing.id, updates);
    res.json({ success: true, message: 'Product updated successfully.', product: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update product.' });
  }
});

// DELETE /api/admin/products/:id - Delete product
router.delete('/products/:id', (req, res) => {
  try {
    const deleted = db.products.remove(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }
    res.json({ success: true, message: 'Product removed from catalog.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete product.' });
  }
});

// PATCH /api/admin/products/:id/stock - Quick inventory adjustment
router.patch('/products/:id/stock', (req, res) => {
  try {
    const { stockQuantity } = req.body;
    if (stockQuantity === undefined) {
      return res.status(400).json({ success: false, message: 'New stock quantity required.' });
    }

    const num = Number(stockQuantity);
    const updated = db.products.update(req.params.id, {
      stockQuantity: num,
      inStock: num > 0
    });

    res.json({ success: true, message: 'Stock updated.', product: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to adjust stock.' });
  }
});

// GET /api/admin/orders - View all customer orders
router.get('/orders', (req, res) => {
  try {
    const { status } = req.query;
    let orders = db.orders.find();

    if (status && status !== 'all') {
      orders = orders.filter(o => o.status.toLowerCase() === status.toLowerCase());
    }

    orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve orders.' });
  }
});

// PATCH /api/admin/orders/:id/status - Update order status & tracking notes
router.patch('/orders/:id/status', (req, res) => {
  try {
    const { status, note, courierPartner, trackingNumber } = req.body;
    const order = db.orders.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    const timeline = order.timeline || [];
    timeline.push({
      status: status || order.status,
      timestamp: new Date().toISOString(),
      note: note || `Order updated to ${status}`
    });

    const updates = {
      status,
      timeline
    };

    if (courierPartner) updates.courierPartner = courierPartner;
    if (trackingNumber) updates.trackingNumber = trackingNumber;
    else if (status === 'Shipped' && !order.trackingNumber) {
      updates.trackingNumber = orderService.generateTrackingNumber(courierPartner || 'Delhivery');
    }

    if (status === 'Delivered') {
      updates.deliveredAt = new Date().toISOString();
      if (order.paymentMethod === 'Cash on Delivery') {
        updates.paymentStatus = 'Paid';
      }
    } else if (status === 'Cancelled') {
      // Restore inventory
      orderService.restoreInventory(order.items || []);
    }

    const updatedOrder = db.orders.update(order.id, updates);
    res.json({ success: true, message: `Order status updated to ${status}.`, order: updatedOrder });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update order status.' });
  }
});

// GET /api/admin/customers - Customer directory
router.get('/customers', (req, res) => {
  try {
    const users = db.users.find({ role: 'customer' });
    const orders = db.orders.find();

    const customers = users.map(u => {
      const userOrders = orders.filter(o => o.userId === u.id || (o.customerEmail && o.customerEmail.toLowerCase() === u.email.toLowerCase()));
      const totalSpent = userOrders
        .filter(o => o.paymentStatus === 'Paid' || o.status === 'Delivered')
        .reduce((sum, o) => sum + (o.total || 0), 0);

      const { password, ...safeUser } = u;
      return {
        ...safeUser,
        orderCount: userOrders.length,
        totalSpent,
        lastOrderDate: userOrders[0]?.createdAt || null
      };
    });

    res.json({ success: true, customers });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve customers.' });
  }
});

// GET /api/admin/settings
router.get('/settings', (req, res) => {
  try {
    const settings = db.settings.findOne({ id: 'store_settings' }) || {};
    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve settings.' });
  }
});

// PUT /api/admin/settings
router.put('/settings', (req, res) => {
  try {
    const existing = db.settings.findOne({ id: 'store_settings' });
    const updated = db.settings.update(existing.id, req.body);
    res.json({ success: true, message: 'Store settings saved successfully.', settings: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update settings.' });
  }
});

module.exports = router;
