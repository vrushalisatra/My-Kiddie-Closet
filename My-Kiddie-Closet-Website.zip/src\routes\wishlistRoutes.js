const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { requireAuth, optionalAuth } = require('../middleware/auth');

// GET /api/wishlist
router.get('/', optionalAuth, (req, res) => {
  try {
    if (!req.user) {
      return res.json({ success: true, items: [] });
    }

    let wishlist = db.wishlists.findOne({ userId: req.user.id });
    if (!wishlist) {
      wishlist = db.wishlists.insert({ userId: req.user.id, productIds: [] });
    }

    const products = wishlist.productIds
      .map(id => db.products.findById(id))
      .filter(Boolean);

    res.json({
      success: true,
      productIds: wishlist.productIds,
      items: products
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve wishlist.' });
  }
});

// POST /api/wishlist/toggle - Adds or removes a product from user's wishlist
router.post('/toggle', requireAuth, (req, res) => {
  try {
    const { productId } = req.body;
    if (!productId) {
      return res.status(400).json({ success: false, message: 'Product ID required.' });
    }

    let wishlist = db.wishlists.findOne({ userId: req.user.id });
    if (!wishlist) {
      wishlist = db.wishlists.insert({ userId: req.user.id, productIds: [] });
    }

    let productIds = [...wishlist.productIds];
    const existsIndex = productIds.indexOf(productId);
    let isWishlisted = false;

    if (existsIndex > -1) {
      productIds.splice(existsIndex, 1);
      isWishlisted = false;
    } else {
      productIds.push(productId);
      isWishlisted = true;
    }

    db.wishlists.update(wishlist.id, { productIds });

    res.json({
      success: true,
      isWishlisted,
      productIds,
      message: isWishlisted ? 'Added to your Wishlist!' : 'Removed from Wishlist.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update wishlist.' });
  }
});

// POST /api/wishlist/sync - Sync guest localStorage wishlist to account on login
router.post('/sync', requireAuth, (req, res) => {
  try {
    const { productIds = [] } = req.body;
    let wishlist = db.wishlists.findOne({ userId: req.user.id });
    if (!wishlist) {
      wishlist = db.wishlists.insert({ userId: req.user.id, productIds: [] });
    }

    const merged = Array.from(new Set([...wishlist.productIds, ...productIds]));
    db.wishlists.update(wishlist.id, { productIds: merged });

    res.json({ success: true, productIds: merged });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to sync wishlist.' });
  }
});

module.exports = router;
