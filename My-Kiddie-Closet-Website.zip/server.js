const express = require('express');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const config = require('./src/config');
const { seedDatabase } = require('./src/db/seed');

// Initialize database
seedDatabase();

const app = express();

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Static public directory
const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir));

// API Routes
app.use('/api/auth', require('./src/routes/authRoutes'));
app.use('/api/products', require('./src/routes/productRoutes'));
app.use('/api/cart', require('./src/routes/cartRoutes'));
app.use('/api/wishlist', require('./src/routes/wishlistRoutes'));
app.use('/api/orders', require('./src/routes/orderRoutes'));
app.use('/api/payments', require('./src/routes/paymentRoutes'));
app.use('/api/admin', require('./src/routes/adminRoutes'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    brand: config.store.name,
    tagline: config.store.tagline,
    timestamp: new Date().toISOString()
  });
});

// HTML page routes (clean URLs)
const pages = [
  { route: '/', file: 'index.html' },
  { route: '/shop', file: 'shop.html' },
  { route: '/collections', file: 'collections.html' },
  { route: '/product', file: 'product.html' },
  { route: '/cart', file: 'cart.html' },
  { route: '/checkout', file: 'checkout.html' },
  { route: '/order-confirmation', file: 'order-confirmation.html' },
  { route: '/track-order', file: 'track-order.html' },
  { route: '/wishlist', file: 'wishlist.html' },
  { route: '/account', file: 'account.html' },
  { route: '/admin', file: 'admin.html' },
  { route: '/shipping-policy', file: 'shipping-policy.html' },
  { route: '/refund-return-policy', file: 'refund-return-policy.html' },
  { route: '/privacy-policy', file: 'privacy-policy.html' },
  { route: '/terms-conditions', file: 'terms-conditions.html' },
  { route: '/size-guide', file: 'size-guide.html' },
  { route: '/contact', file: 'contact.html' }
];

pages.forEach(({ route, file }) => {
  app.get(route, (req, res) => {
    res.sendFile(file, { root: publicDir });
  });
});

// Fallback for SPA/direct file requests
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    // If asking for a .html file that exists
    const candidate = path.join(publicDir, `${req.path}.html`);
    const fs = require('fs');
    if (fs.existsSync(candidate)) {
      return res.sendFile(candidate);
    }
  }
  next();
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error occurred.'
  });
});

const PORT = config.port;
app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`  My Kiddie Closet - E-Commerce Server`);
  console.log(`  "Little Looks for Big Imaginations"`);
  console.log(`  Listening at: http://localhost:${PORT}`);
  console.log(`=======================================================`);
});
