const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

class Collection {
  constructor(name) {
    this.name = name;
    this.filePath = path.join(DATA_DIR, `${name}.json`);
    this.data = [];
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        this.data = [];
        this.save();
      }
    } catch (err) {
      console.error(`Error loading collection ${this.name}:`, err);
      this.data = [];
    }
  }

  save() {
    try {
      const tempPath = `${this.filePath}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error(`Error saving collection ${this.name}:`, err);
    }
  }

  find(predicate = () => true) {
    this.load(); // Ensure fresh data
    if (typeof predicate === 'function') {
      return this.data.filter(predicate);
    }
    // Object query match (simple filter)
    return this.data.filter(item => {
      return Object.keys(predicate).every(key => item[key] === predicate[key]);
    });
  }

  findOne(predicate) {
    this.load();
    if (typeof predicate === 'function') {
      return this.data.find(predicate) || null;
    }
    return this.data.find(item => {
      return Object.keys(predicate).every(key => item[key] === predicate[key]);
    }) || null;
  }

  findById(id) {
    return this.findOne({ id: String(id) });
  }

  insert(doc) {
    this.load();
    const newDoc = {
      ...doc,
      id: doc.id ? String(doc.id) : (Date.now() + Math.random().toString(36).substring(2, 7)),
      createdAt: doc.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.data.push(newDoc);
    this.save();
    return newDoc;
  }

  insertMany(docs) {
    this.load();
    const created = docs.map(doc => ({
      ...doc,
      id: doc.id ? String(doc.id) : (Date.now() + Math.random().toString(36).substring(2, 7)),
      createdAt: doc.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
    this.data.push(...created);
    this.save();
    return created;
  }

  update(id, updates) {
    this.load();
    const index = this.data.findIndex(item => String(item.id) === String(id));
    if (index === -1) return null;
    const updated = {
      ...this.data[index],
      ...updates,
      id: String(id), // ID remains immutable
      updatedAt: new Date().toISOString()
    };
    this.data[index] = updated;
    this.save();
    return updated;
  }

  remove(id) {
    this.load();
    const index = this.data.findIndex(item => String(item.id) === String(id));
    if (index === -1) return false;
    this.data.splice(index, 1);
    this.save();
    return true;
  }

  count(predicate = () => true) {
    return this.find(predicate).length;
  }
}

const collections = {};

function getCollection(name) {
  if (!collections[name]) {
    collections[name] = new Collection(name);
  }
  return collections[name];
}

module.exports = {
  users: getCollection('users'),
  products: getCollection('products'),
  orders: getCollection('orders'),
  wishlists: getCollection('wishlists'),
  reviews: getCollection('reviews'),
  coupons: getCollection('coupons'),
  settings: getCollection('settings'),
  getCollection
};
