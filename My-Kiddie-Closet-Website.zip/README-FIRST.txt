========================================================================
   MY KIDDIE CLOSET - PRODUCTION-READY E-COMMERCE WEBSITE
   Tagline: "Little Looks for Big Imaginations"
   Primary Brand Colours: Baby Pink & Baby Blue
========================================================================

📁 WHAT IS IN THIS FOLDER:
------------------------------------------------------------------------
• start-store.bat         -> Double-click this file to launch the website!
• server.js               -> Express.js backend server with Razorpay, Auth & API
• package.json            -> Dependencies and project configuration
• .env                    -> Port, JWT secrets, and payment configuration
• public/                 -> Complete Frontend (17 responsive HTML pages, CSS, JS)
  ├── index.html          -> Premium Homepage with hero, collections & reviews
  ├── shop.html           -> Catalog with filters (Age, Category, Size, Price)
  ├── collections.html    -> Baby & Toddler, Girls Twirls, Boys Collections
  ├── product.html        -> Detailed product page with photo gallery & size guide
  ├── cart.html           -> Interactive cart with promo codes (LITTLE10)
  ├── checkout.html       -> Secure 256-bit SSL checkout with Razorpay + COD
  ├── order-confirmation  -> Real-time order placement confirmation
  ├── track-order.html    -> Live order tracking with progress bar
  ├── wishlist.html       -> Wishlist management
  ├── account.html        -> Customer profile, order history & addresses
  ├── admin.html          -> Admin dashboard (manage inventory, orders, prices)
  ├── shipping-policy.html, refund-return-policy.html, privacy-policy.html, etc.
  ├── images/branding/    -> Official Logo, Mascot, and Favicon
  ├── js/                 -> Store logic (store.js), API client, components.js
  └── css/styles.css      -> Tailored pastel styles, animations & micro-interactions

• src/                    -> Backend Source Code & Database
  ├── config/             -> App settings and Razorpay credentials
  ├── db/                 -> Atomic file-backed JSON database engine
  │   └── data/           -> YOUR STORE DATA (products, orders, users, reviews)
  ├── routes/             -> RESTful API endpoints for auth, products, cart, etc.
  └── services/           -> Payment and order management services

------------------------------------------------------------------------
🔑 DEMO ACCOUNTS & CREDENTIALS:
------------------------------------------------------------------------
Admin Dashboard URL: http://localhost:5000/admin
Admin Email:         admin@mykiddiecloset.com
Admin Password:      Admin@123

Demo Customer Email: priya.sharma@example.com
Demo Customer Pass:  Customer@123

Active Promo Codes:
• LITTLE10   -> 10% discount on any order
• WELCOME15  -> 15% discount for new parents
• FREESHIP   -> Free shipping voucher

------------------------------------------------------------------------
🚀 HOW TO RUN THE WEBSITE:
------------------------------------------------------------------------
1. Simply double-click "start-store.bat" in this folder.
2. The server will start and automatically open http://localhost:5000 in your browser!

------------------------------------------------------------------------
📦 DATABASE & DATA BACKUP:
------------------------------------------------------------------------
All your store data (products, prices, customer orders, reviews, and stock)
is stored as human-readable JSON files in:
   src\db\data\

You can safely back up this entire folder at any time.
========================================================================