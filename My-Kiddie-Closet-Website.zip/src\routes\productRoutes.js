const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { optionalAuth } = require('../middleware/auth');

// GET /api/products - Main catalog with filtering, search & sorting
router.get('/', (req, res) => {
  try {
    let {
      collection,
      category,
      ageGroup,
      size,
      color,
      minPrice,
      maxPrice,
      search,
      sort = 'featured',
      bestseller,
      isNew,
      featured,
      page = 1,
      limit = 24
    } = req.query;

    let items = db.products.find();

    // 1. Collection filter
    if (collection && collection !== 'all') {
      items = items.filter(p => p.collection.toLowerCase() === collection.toLowerCase());
    }

    // 2. Category filter
    if (category && category !== 'all') {
      items = items.filter(p => p.category && p.category.toLowerCase() === category.toLowerCase());
    }

    // 3. Age Group filter
    if (ageGroup && ageGroup !== 'all') {
      const ageArr = Array.isArray(ageGroup) ? ageGroup : ageGroup.split(',');
      items = items.filter(p => ageArr.some(a => (p.ageGroup || '').toLowerCase() === a.toLowerCase()));
    }

    // 4. Size filter
    if (size && size !== 'all') {
      const sizeArr = Array.isArray(size) ? size : size.split(',');
      items = items.filter(p => {
        if (!p.sizes) return false;
        return p.sizes.some(s => sizeArr.includes(s.size) && s.stock > 0);
      });
    }

    // 5. Color filter
    if (color && color !== 'all') {
      const colorArr = Array.isArray(color) ? color : color.split(',');
      items = items.filter(p => {
        if (!p.colors) return false;
        return p.colors.some(c => colorArr.some(col => c.name.toLowerCase().includes(col.toLowerCase())));
      });
    }

    // 6. Price range filter
    if (minPrice) {
      const min = Number(minPrice);
      if (!isNaN(min)) items = items.filter(p => p.price >= min);
    }
    if (maxPrice) {
      const max = Number(maxPrice);
      if (!isNaN(max)) items = items.filter(p => p.price <= max);
    }

    // 7. Search text
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      items = items.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.tagline && p.tagline.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q)) ||
        (p.collection && p.collection.toLowerCase().includes(q)) ||
        (p.sku && p.sku.toLowerCase().includes(q))
      );
    }

    // 8. Badges filter
    if (bestseller === 'true') items = items.filter(p => p.bestseller);
    if (isNew === 'true') items = items.filter(p => p.isNew);
    if (featured === 'true') items = items.filter(p => p.featured);

    // 9. Sorting
    switch (sort) {
      case 'price-low':
        items.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        items.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'rating':
        items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'bestseller':
        items.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
        break;
      case 'featured':
      default:
        items.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    // Total count before pagination
    const totalCount = items.length;

    // Pagination
    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 24;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = items.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      total: totalCount,
      page: pageNum,
      totalPages: Math.ceil(totalCount / limitNum),
      products: paginatedItems
    });
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ success: false, message: 'Failed to retrieve products.' });
  }
});

// GET /api/products/filters - Meta list of categories, age groups, sizes, colors for filter UI
router.get('/filters', (req, res) => {
  try {
    const products = db.products.find();

    const categories = [...new Set(products.map(p => p.category).filter(Boolean))];
    const ageGroups = ['0-6M', '6-12M', '1-2Y', '2-4Y', '4-6Y'];
    const collections = ['baby-toddler', 'boys', 'girls'];

    const sizeSet = new Set();
    const colorMap = new Map();

    products.forEach(p => {
      if (p.sizes) {
        p.sizes.forEach(s => sizeSet.add(s.size));
      }
      if (p.colors) {
        p.colors.forEach(c => {
          if (!colorMap.has(c.name)) {
            colorMap.set(c.name, c.hex);
          }
        });
      }
    });

    const prices = products.map(p => p.price);
    const minPrice = prices.length ? Math.min(...prices) : 499;
    const maxPrice = prices.length ? Math.max(...prices) : 2999;

    res.json({
      success: true,
      filters: {
        collections,
        categories,
        ageGroups,
        sizes: Array.from(sizeSet),
        colors: Array.from(colorMap.entries()).map(([name, hex]) => ({ name, hex })),
        priceRange: { min: minPrice, max: maxPrice }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve filter options.' });
  }
});

// GET /api/products/featured - Curated for homepage sections
router.get('/featured', (req, res) => {
  try {
    const products = db.products.find();
    res.json({
      success: true,
      bestsellers: products.filter(p => p.bestseller).slice(0, 8),
      newArrivals: products.filter(p => p.isNew).slice(0, 8),
      babyEssentials: products.filter(p => p.collection === 'baby-toddler').slice(0, 8),
      boysFeatured: products.filter(p => p.collection === 'boys').slice(0, 4),
      girlsFeatured: products.filter(p => p.collection === 'girls').slice(0, 4)
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve featured products.' });
  }
});

// GET /api/products/:idOrSlug
router.get('/:idOrSlug', (req, res) => {
  try {
    const { idOrSlug } = req.params;
    const product = db.products.findOne(p => p.id === idOrSlug || p.slug === idOrSlug);

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Related products in same collection
    const related = db.products.find(p => p.collection === product.collection && p.id !== product.id).slice(0, 4);

    // Reviews for this product
    const reviews = db.reviews.find({ productId: product.id });

    res.json({
      success: true,
      product,
      related,
      reviews
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve product details.' });
  }
});

// POST /api/products/:id/reviews - Add customer review
router.post('/:id/reviews', optionalAuth, (req, res) => {
  try {
    const product = db.products.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const { rating, title, comment, userName, userCity } = req.body;
    if (!rating || !comment) {
      return res.status(400).json({ success: false, message: 'Rating and comment are required.' });
    }

    const newReview = db.reviews.insert({
      productId: product.id,
      userId: req.user ? req.user.id : null,
      userName: req.user ? req.user.name : (userName || 'Parent'),
      userCity: userCity || 'India',
      rating: Number(rating),
      title: title || 'Great Quality!',
      comment,
      verifiedPurchase: Boolean(req.user)
    });

    // Re-calculate product average rating
    const allReviews = db.reviews.find({ productId: product.id });
    const avgRating = (allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length).toFixed(1);

    db.products.update(product.id, {
      rating: parseFloat(avgRating),
      reviewCount: allReviews.length
    });

    res.status(201).json({ success: true, message: 'Review submitted. Thank you!', review: newReview });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to submit review.' });
  }
});

module.exports = router;
