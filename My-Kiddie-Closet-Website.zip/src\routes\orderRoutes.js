const express = require('express');
const router = express.Router();
const db = require('../db/database');
const orderService = require('../services/orderService');
const paymentService = require('../services/paymentService');
const { optionalAuth, requireAuth } = require('../middleware/auth');
const config = require('../config');

// POST /api/orders - Place a new real order
router.post('/', optionalAuth, async (req, res) => {
  try {
    const {
      items = [],
      shippingAddress,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod = 'Razorpay', // 'Razorpay' or 'COD'
      couponCode,
      shippingOption = 'standard' // 'standard' or 'express'
    } = req.body;

    if (!items.length) {
      return res.status(400).json({ success: false, message: 'Cart is empty. Add products before checkout.' });
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.addressLine1 || !shippingAddress.city || !shippingAddress.pincode) {
      return res.status(400).json({ success: false, message: 'Complete shipping address is required.' });
    }

    // Validate items and calculate prices from DB
    let subtotal = 0;
    const validatedItems = [];

    for (const item of items) {
      const product = db.products.findById(item.productId);
      if (!product) continue;

      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const itemPrice = product.price;
      subtotal += itemPrice * qty;

      validatedItems.push({
        productId: product.id,
        name: product.name,
        slug: product.slug,
        price: itemPrice,
        quantity: qty,
        size: item.size || 'Standard',
        color: item.color || 'Pastel',
        image: item.image || (product.images && product.images[0]) || ''
      });
    }

    if (!validatedItems.length) {
      return res.status(400).json({ success: false, message: 'No valid products in order.' });
    }

    // Calculate coupon discount
    let discount = 0;
    let appliedCoupon = null;

    if (couponCode) {
      const coupon = db.coupons.findOne(c => c.code.toUpperCase() === couponCode.trim().toUpperCase() && c.isActive);
      if (coupon && (!coupon.minOrderAmount || subtotal >= coupon.minOrderAmount)) {
        appliedCoupon = coupon.code;
        if (coupon.discountType === 'percentage') {
          discount = Math.round((subtotal * coupon.discountValue) / 100);
        } else if (coupon.discountType === 'fixed') {
          discount = Math.min(coupon.discountValue, subtotal);
        } else if (coupon.discountType === 'shipping') {
          discount = config.store.standardShippingFee;
        }
      }
    }

    // Shipping fee
    let shippingFee = 0;
    if (subtotal < config.store.freeShippingThreshold) {
      shippingFee = shippingOption === 'express' ? config.store.expressShippingFee : config.store.standardShippingFee;
    } else if (shippingOption === 'express') {
      shippingFee = 99; // discounted express
    }

    if (appliedCoupon === 'FREESHIP') {
      shippingFee = 0;
    }

    const total = Math.max(0, subtotal - discount + shippingFee);
    const orderNumber = orderService.generateOrderNumber();
    const trackingNumber = orderService.generateTrackingNumber('Delhivery');

    const estimatedDays = shippingOption === 'express' ? 3 : 5;
    const estDeliveryDate = new Date();
    estDeliveryDate.setDate(estDeliveryDate.getDate() + estimatedDays);

    const isCOD = paymentMethod === 'COD' || paymentMethod === 'Cash on Delivery';

    const orderData = {
      orderNumber,
      userId: req.user ? req.user.id : null,
      customerName: customerName || shippingAddress.fullName,
      customerEmail: customerEmail || (req.user ? req.user.email : ''),
      customerPhone: customerPhone || shippingAddress.phone,
      shippingAddress,
      items: validatedItems,
      subtotal,
      discount,
      couponCode: appliedCoupon,
      shippingFee,
      shippingOption,
      total,
      paymentMethod: isCOD ? 'Cash on Delivery' : 'Razorpay Online',
      paymentStatus: isCOD ? 'Pending on Delivery' : 'Payment Pending',
      status: isCOD ? 'Confirmed' : 'Payment Pending',
      courierPartner: 'Delhivery Express',
      trackingNumber,
      estimatedDelivery: estDeliveryDate.toISOString().split('T')[0],
      timeline: [
        {
          status: 'Order Placed',
          timestamp: new Date().toISOString(),
          note: isCOD ? 'Order placed with Cash on Delivery' : 'Order initiated. Awaiting Razorpay payment.'
        }
      ]
    };

    const newOrder = db.orders.insert(orderData);

    // If COD, deduct inventory right away
    if (isCOD) {
      orderService.deductInventory(validatedItems);
    }

    // If Razorpay, initiate payment order
    let razorpayOrder = null;
    if (!isCOD) {
      razorpayOrder = await paymentService.createRazorpayOrder(total, newOrder.orderNumber, {
        orderId: newOrder.id,
        orderNumber: newOrder.orderNumber
      });
    }

    res.status(201).json({
      success: true,
      message: isCOD ? 'Order confirmed! We will pack and ship your little looks soon.' : 'Order created. Ready for payment.',
      order: newOrder,
      razorpayOrder
    });
  } catch (err) {
    console.error('Order creation error:', err);
    res.status(500).json({ success: false, message: 'Failed to process order.' });
  }
});

// GET /api/orders/my-orders - Logged in customer orders
router.get('/my-orders', requireAuth, (req, res) => {
  try {
    const orders = db.orders
      .find(o => o.userId === req.user.id || (o.customerEmail && o.customerEmail.toLowerCase() === req.user.email.toLowerCase()))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve order history.' });
  }
});

// GET /api/orders/track/:query - Public & live order tracker
router.get('/track/:query', (req, res) => {
  try {
    const { query } = req.params;
    const cleanQuery = query.trim().toUpperCase();

    const order = db.orders.findOne(o =>
      (o.id && o.id.toUpperCase() === cleanQuery) ||
      (o.orderNumber && o.orderNumber.toUpperCase() === cleanQuery) ||
      (o.trackingNumber && o.trackingNumber.toUpperCase() === cleanQuery)
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: `No order found with Tracking / Order ID "${query}". Please check your order confirmation email or SMS.`
      });
    }

    res.json({
      success: true,
      order: {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        createdAt: order.createdAt,
        estimatedDelivery: order.estimatedDelivery,
        courierPartner: order.courierPartner,
        trackingNumber: order.trackingNumber,
        shippingAddress: {
          city: order.shippingAddress?.city,
          state: order.shippingAddress?.state,
          pincode: order.shippingAddress?.pincode
        },
        itemsCount: order.items?.length || 0,
        items: order.items,
        total: order.total,
        timeline: order.timeline || []
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to track order.' });
  }
});

// GET /api/orders/:id - Single order details
router.get('/:id', optionalAuth, (req, res) => {
  try {
    const order = db.orders.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch order.' });
  }
});

module.exports = router;
