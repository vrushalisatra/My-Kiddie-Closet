/**
 * My Kiddie Closet - Reusable UI Components & Site Shell
 */

const Components = {
  renderHeader() {
    const headerContainer = document.getElementById('site-header');
    if (!headerContainer) return;

    headerContainer.innerHTML = `
      <!-- Top Announcement Bar -->
      <div class="bg-gradient-to-r from-pink-400 via-pink-300 to-sky-300 text-white text-xs py-2 px-4 text-center font-medium shadow-sm flex items-center justify-center gap-2">
        <span class="animate-bounce">✨</span>
        <span><b>Welcome to My Kiddie Closet!</b> Free Express Shipping on orders over ₹999 | Use code <b>LITTLE10</b> for 10% off</span>
        <span class="animate-bounce">🧸</span>
      </div>

      <!-- Main Navigation Bar -->
      <nav class="bg-white/95 backdrop-blur-md border-b border-pink-100/60 sticky top-0 z-50 transition-all shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex items-center justify-between h-20 gap-4">
            
            <!-- Brand Logo -->
            <a href="/" class="flex items-center flex-shrink-0 group py-1" title="My Kiddie Closet - Little Looks for Big Imaginations">
              <img 
                src="/images/branding/logo.png" 
                alt="My Kiddie Closet - Little Looks for Big Imaginations" 
                class="h-14 sm:h-16 w-auto object-contain group-hover:scale-105 transition-transform duration-300"
              >
            </a>

            <!-- Search Bar (Desktop) -->
            <div class="hidden md:flex flex-1 max-w-md mx-4 relative" id="header-search-container">
              <form action="/shop" method="GET" class="w-full relative">
                <input 
                  type="text" 
                  name="search" 
                  id="global-search-input"
                  placeholder="Search baby onesies, girls frocks, boys sets..." 
                  autocomplete="off"
                  class="w-full pl-10 pr-4 py-2.5 rounded-full border border-slate-200 focus:outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-100 text-sm transition bg-slate-50/60 hover:bg-white"
                >
                <div class="absolute left-3.5 top-3 text-slate-400">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
              </form>
              <div id="search-autocomplete-dropdown" class="hidden absolute left-0 right-0 top-12 bg-white rounded-2xl shadow-xl border border-slate-100 p-3 z-50 max-h-80 overflow-y-auto"></div>
            </div>

            <!-- Desktop Nav Links -->
            <div class="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-700">
              <a href="/shop" class="hover:text-pink-500 transition py-1 border-b-2 border-transparent hover:border-pink-400">Shop All</a>
              <a href="/shop?collection=baby-toddler" class="hover:text-pink-500 transition py-1 border-b-2 border-transparent hover:border-pink-400 flex items-center gap-1">
                <span>Baby & Toddler</span>
                <span class="w-2 h-2 rounded-full bg-pink-400"></span>
              </a>
              <a href="/shop?collection=girls" class="hover:text-pink-500 transition py-1 border-b-2 border-transparent hover:border-pink-400">Girls</a>
              <a href="/shop?collection=boys" class="hover:text-pink-500 transition py-1 border-b-2 border-transparent hover:border-pink-400">Boys</a>
              <a href="/track-order" class="hover:text-sky-600 transition py-1 text-slate-500 flex items-center gap-1">
                <svg class="w-4 h-4 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
                <span>Track Order</span>
              </a>
            </div>

            <!-- Right Actions (Wishlist, Cart, Account) -->
            <div class="flex items-center gap-3">
              <!-- Wishlist Icon -->
              <a href="/wishlist" class="relative p-2.5 rounded-full text-slate-700 hover:text-pink-500 hover:bg-pink-50 transition" title="My Wishlist">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
                <span class="wishlist-badge-count absolute -top-1 -right-1 w-5 h-5 rounded-full bg-pink-500 text-white font-bold text-[10px] items-center justify-center shadow-sm" style="display:none;">0</span>
              </a>

              <!-- Cart Drawer Button -->
              <button onclick="Store.openCartDrawer()" class="relative p-2.5 rounded-full text-slate-700 hover:text-sky-600 hover:bg-sky-50 transition" title="Shopping Cart">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                <span class="cart-badge-count absolute -top-1 -right-1 w-5 h-5 rounded-full bg-sky-500 text-white font-bold text-[10px] items-center justify-center shadow-sm" style="display:none;">0</span>
              </button>

              <!-- Account Pill -->
              <div class="user-account-pill pl-2"></div>
            </div>

          </div>
        </div>
      </nav>
    `;

    this.initSearchAutoComplete();
  },

  initSearchAutoComplete() {
    const input = document.getElementById('global-search-input');
    const dropdown = document.getElementById('search-autocomplete-dropdown');
    if (!input || !dropdown) return;

    let debounceTimer;
    input.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      const q = e.target.value.trim();
      if (q.length < 2) {
        dropdown.classList.add('hidden');
        return;
      }

      debounceTimer = setTimeout(async () => {
        try {
          const res = await API.products.list({ search: q, limit: 5 });
          if (res.products && res.products.length > 0) {
            dropdown.innerHTML = res.products.map(p => `
              <a href="/product?id=${p.id}" class="flex items-center gap-3 p-2 hover:bg-pink-50/60 rounded-xl transition">
                <img src="${p.images[0]}" class="w-10 h-12 object-cover rounded-md flex-shrink-0">
                <div class="flex-1 min-w-0 text-left">
                  <p class="text-xs font-bold text-slate-800 truncate">${p.name}</p>
                  <p class="text-[11px] text-pink-600 font-semibold">₹${p.price} <span class="line-through text-slate-400">₹${p.originalPrice}</span></p>
                </div>
              </a>
            `).join('') + `
              <div class="pt-2 border-t border-slate-100 text-center">
                <a href="/shop?search=${encodeURIComponent(q)}" class="text-xs font-bold text-pink-600 hover:underline">View all results for "${q}" &rarr;</a>
              </div>
            `;
            dropdown.classList.remove('hidden');
          } else {
            dropdown.innerHTML = `<p class="text-xs text-slate-400 text-center py-2">No matching products found</p>`;
            dropdown.classList.remove('hidden');
          }
        } catch (err) {
          dropdown.classList.add('hidden');
        }
      }, 250);
    });

    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.add('hidden');
      }
    });
  },

  renderCartDrawer() {
    let drawerContainer = document.getElementById('cart-drawer-container');
    if (!drawerContainer) {
      drawerContainer = document.createElement('div');
      drawerContainer.id = 'cart-drawer-container';
      document.body.appendChild(drawerContainer);
    }

    drawerContainer.innerHTML = `
      <div id="cart-drawer-overlay" class="cart-drawer-overlay" onclick="Store.closeCartDrawer()"></div>
      <div id="cart-drawer" class="cart-drawer">
        
        <!-- Drawer Header -->
        <div class="p-5 border-b border-slate-100 flex items-center justify-between bg-pink-50/40">
          <div class="flex items-center gap-2">
            <span class="text-xl">🛍️</span>
            <h3 class="text-lg font-bold text-slate-800 brand-font">Your Kiddie Bag</h3>
          </div>
          <button onclick="Store.closeCartDrawer()" class="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-800 text-lg transition">
            &times;
          </button>
        </div>

        <!-- Free Shipping Progress Meter -->
        <div class="px-5 py-3 bg-sky-50/60 border-b border-sky-100">
          <p id="drawer-shipping-text" class="text-xs text-slate-700 font-medium mb-1.5"></p>
          <div class="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
            <div id="drawer-shipping-progress" class="h-full bg-gradient-to-r from-sky-400 to-pink-400 transition-all duration-300" style="width: 0%;"></div>
          </div>
        </div>

        <!-- Items Container -->
        <div id="drawer-items-list" class="flex-1 overflow-y-auto p-5 space-y-3"></div>

        <!-- Drawer Footer -->
        <div class="p-5 border-t border-slate-100 bg-white">
          <div class="flex items-center justify-between mb-4">
            <span class="text-sm font-semibold text-slate-600">Subtotal:</span>
            <span id="drawer-subtotal" class="text-xl font-extrabold text-slate-900">₹0</span>
          </div>
          <p class="text-[11px] text-slate-400 mb-4 text-center">Taxes & shipping calculated at checkout. Free shipping over ₹999.</p>
          <div class="grid grid-cols-2 gap-3">
            <a href="/cart" onclick="Store.closeCartDrawer()" class="btn-outline-pink text-xs text-center justify-center">View Cart</a>
            <a href="/checkout" id="drawer-checkout-btn" onclick="Store.closeCartDrawer()" class="btn-primary text-xs text-center justify-center">Checkout</a>
          </div>
        </div>

      </div>
    `;
  },

  renderFooter() {
    const footerContainer = document.getElementById('site-footer');
    if (!footerContainer) return;

    footerContainer.innerHTML = `
      <footer class="bg-white border-t border-slate-200/80 pt-16 pb-12 mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <!-- Trust Badges Row -->
          <div class="grid grid-cols-2 md:grid-cols-4 gap-6 pb-12 mb-12 border-b border-slate-100">
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-pink-100 text-pink-600 flex items-center justify-center text-xl flex-shrink-0">🌱</div>
              <div>
                <h4 class="text-sm font-bold text-slate-800">100% Organic Cotton</h4>
                <p class="text-xs text-slate-500">Certified safe for newborn skin</p>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center text-xl flex-shrink-0">🚚</div>
              <div>
                <h4 class="text-sm font-bold text-slate-800">Free Express Delivery</h4>
                <p class="text-xs text-slate-500">Across India on orders over ₹999</p>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-pink-100 text-pink-600 flex items-center justify-center text-xl flex-shrink-0">🔄</div>
              <div>
                <h4 class="text-sm font-bold text-slate-800">15-Day Easy Returns</h4>
                <p class="text-xs text-slate-500">Hassle-free doorstep exchanges</p>
              </div>
            </div>
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center text-xl flex-shrink-0">💳</div>
              <div>
                <h4 class="text-sm font-bold text-slate-800">Razorpay & COD</h4>
                <p class="text-xs text-slate-500">UPI, Cards, EMI & Cash on Delivery</p>
              </div>
            </div>
          </div>

          <!-- Footer Links & Newsletter -->
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12">
            
            <!-- Brand Info -->
            <div class="lg:col-span-2 space-y-4">
              <a href="/" class="inline-block">
                <img src="/images/branding/logo.png" alt="My Kiddie Closet - Little Looks for Big Imaginations" class="h-16 sm:h-20 w-auto object-contain">
              </a>
              <p class="text-sm text-slate-500 font-medium leading-relaxed">
                "Little Looks for Big Imaginations." Premium, cloud-soft, and whimsical childrenswear carefully crafted for newborns, babies, toddlers, and playful young kids.
              </p>
              <div class="flex items-center gap-3 text-slate-400 pt-2">
                <span class="text-xs font-semibold text-slate-600">Registered in India 🇮🇳</span>
                <span>•</span>
                <span class="text-xs text-slate-500">Mumbai • Bengaluru • Delhi NCR</span>
              </div>
            </div>

            <!-- Collections Links -->
            <div>
              <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">Collections</h4>
              <ul class="space-y-2.5 text-sm text-slate-600 font-medium">
                <li><a href="/shop?collection=baby-toddler" class="hover:text-pink-600 transition">Baby & Toddler (0-2Y)</a></li>
                <li><a href="/shop?collection=girls" class="hover:text-pink-600 transition">Girls Twirls & Frocks</a></li>
                <li><a href="/shop?collection=boys" class="hover:text-pink-600 transition">Boys Sets & Polos</a></li>
                <li><a href="/shop?category=Sleepwear%20%26%20Rompers" class="hover:text-pink-600 transition">Organic Sleepwear</a></li>
                <li><a href="/shop?bestseller=true" class="hover:text-pink-600 transition">Bestsellers</a></li>
              </ul>
            </div>

            <!-- Customer Care -->
            <div>
              <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">Customer Care</h4>
              <ul class="space-y-2.5 text-sm text-slate-600 font-medium">
                <li><a href="/track-order" class="hover:text-sky-600 transition font-bold text-sky-600">Track Your Order 🚚</a></li>
                <li><a href="/shipping-policy" class="hover:text-pink-600 transition">Shipping Policy</a></li>
                <li><a href="/refund-return-policy" class="hover:text-pink-600 transition">Returns & Exchanges</a></li>
                <li><a href="/size-guide" class="hover:text-pink-600 transition">Interactive Size Guide</a></li>
                <li><a href="/contact" class="hover:text-pink-600 transition">Contact Us & WhatsApp</a></li>
              </ul>
            </div>

            <!-- Legal & Admin -->
            <div>
              <h4 class="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">Company & Legal</h4>
              <ul class="space-y-2.5 text-sm text-slate-600 font-medium">
                <li><a href="/privacy-policy" class="hover:text-pink-600 transition">Privacy Policy</a></li>
                <li><a href="/terms-conditions" class="hover:text-pink-600 transition">Terms & Conditions</a></li>
                <li><a href="/account" class="hover:text-pink-600 transition">My Account</a></li>
                <li><a href="/admin" class="hover:text-slate-900 transition flex items-center gap-1 text-slate-400">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                  <span>Admin Dashboard</span>
                </a></li>
              </ul>
            </div>

          </div>

          <!-- Bottom Copyright & Payments Bar -->
          <div class="pt-8 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>&copy; 2026 My Kiddie Closet. All rights reserved. Crafted with 💖 in Baby Pink & Baby Blue.</p>
            <div class="flex items-center gap-2">
              <span class="font-semibold text-slate-600 mr-2">Secure Payments:</span>
              <span class="px-2 py-1 bg-slate-100 rounded text-[11px] font-bold text-slate-700">Razorpay</span>
              <span class="px-2 py-1 bg-slate-100 rounded text-[11px] font-bold text-slate-700">UPI</span>
              <span class="px-2 py-1 bg-slate-100 rounded text-[11px] font-bold text-slate-700">RuPay</span>
              <span class="px-2 py-1 bg-slate-100 rounded text-[11px] font-bold text-slate-700">Cards</span>
              <span class="px-2 py-1 bg-slate-100 rounded text-[11px] font-bold text-slate-700">COD</span>
            </div>
          </div>

        </div>
      </footer>
    `;
  },

  renderMobileBottomNav() {
    let navContainer = document.getElementById('mobile-bottom-nav');
    if (!navContainer) {
      navContainer = document.createElement('div');
      navContainer.id = 'mobile-bottom-nav';
      navContainer.className = 'mobile-bottom-nav fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 py-2 px-6 z-40 flex items-center justify-between shadow-lg';
      document.body.appendChild(navContainer);
    }

    navContainer.innerHTML = `
      <a href="/" class="flex flex-col items-center gap-1 text-slate-600 hover:text-pink-500 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
        <span class="text-[10px] font-bold">Home</span>
      </a>
      <a href="/shop" class="flex flex-col items-center gap-1 text-slate-600 hover:text-pink-500 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
        <span class="text-[10px] font-bold">Shop</span>
      </a>
      <a href="/wishlist" class="relative flex flex-col items-center gap-1 text-slate-600 hover:text-pink-500 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
        <span class="wishlist-badge-count absolute -top-1 right-2 w-4 h-4 rounded-full bg-pink-500 text-white font-bold text-[9px] items-center justify-center" style="display:none;">0</span>
        <span class="text-[10px] font-bold">Wishlist</span>
      </a>
      <button onclick="Store.openCartDrawer()" class="relative flex flex-col items-center gap-1 text-slate-600 hover:text-sky-500 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
        <span class="cart-badge-count absolute -top-1 right-2 w-4 h-4 rounded-full bg-sky-500 text-white font-bold text-[9px] items-center justify-center" style="display:none;">0</span>
        <span class="text-[10px] font-bold">Bag</span>
      </button>
      <a href="/account" class="flex flex-col items-center gap-1 text-slate-600 hover:text-pink-500 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
        <span class="text-[10px] font-bold">Account</span>
      </a>
    `;
  },

  renderFloatingWhatsApp() {
    let wa = document.getElementById('floating-whatsapp-widget');
    if (!wa) {
      wa = document.createElement('a');
      wa.id = 'floating-whatsapp-widget';
      wa.className = 'floating-whatsapp hidden sm:flex';
      wa.target = '_blank';
      wa.href = 'https://wa.me/919876543210?text=Hi%20My%20Kiddie%20Closet!%20I%20have%20a%20question%20about%20your%20collection.';
      wa.innerHTML = `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.664-.698c.969.586 1.761.88 2.796.88 3.182 0 5.768-2.587 5.768-5.766.001-3.187-2.575-5.77-5.768-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.312.045-.694.074-2.146-.523-1.748-.718-2.883-2.502-2.969-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86.173.086.275.072.376-.044.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564c.173.087.289.129.332.202.043.073.043.419-.101.824z"/></svg>
        <span>Parent Support</span>
      `;
      document.body.appendChild(wa);
    }
  },

  // Initialize all components on page load
  init() {
    this.renderHeader();
    this.renderCartDrawer();
    this.renderFooter();
    this.renderMobileBottomNav();
    this.renderFloatingWhatsApp();
    Store.updateBadges();
  }
};

window.Components = Components;
document.addEventListener('DOMContentLoaded', () => Components.init());
