const express = require('express');
const router = express.Router();
const paymentService = require('../services/paymentService');
const orderService = require('../services/orderService');
const db = require('../db/database');
const config = require('../config');

// POST /api/payments/razorpay/create-order
router.post('/razorpay/create-order', async (req, res) => {
  try {
    const { amount, receipt = 'rcpt_' + Date.now().toString(36), notes = {} } = req.body;
    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid payment amount.' });
    }

    const orderData = await paymentService.createRazorpayOrder(amount, receipt, notes);
    res.json({
      success: true,
      order: orderData,
      storeName: config.store.name,
      description: config.store.tagline,
      themeColor: '#89CFF0'
    });
  } catch (err) {
    console.error('Razorpay order creation error:', err);
    res.status(500).json({ success: false, message: 'Failed to initiate Razorpay transaction.' });
  }
});

// POST /api/payments/razorpay/verify-payment
router.post('/razorpay/verify-payment', async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id) {
      return res.status(400).json({ success: false, message: 'Missing payment verification tokens.' });
    }

    const isValid = paymentService.verifyPaymentSignature(
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    );

    if (!isValid) {
      return res.status(400).json({ success: false, message: 'Payment signature verification failed.' });
    }

    // If internal order exists, mark as paid
    if (orderId) {
      const order = db.orders.findById(orderId);
      if (order) {
        const timeline = order.timeline || [];
        timeline.push({
          status: 'Payment Received',
          timestamp: new Date().toISOString(),
          note: `Verified via Razorpay (Payment ID: ${razorpay_payment_id})`
        });

        db.orders.update(order.id, {
          paymentStatus: 'Paid',
          razorpayPaymentId: razorpay_payment_id,
          razorpayOrderId: razorpay_order_id,
          status: 'Confirmed',
          timeline
        });

        // Deduct inventory
        orderService.deductInventory(order.items || []);
      }
    }

    res.json({
      success: true,
      message: 'Payment verified and confirmed successfully!',
      paymentId: razorpay_payment_id
    });
  } catch (err) {
    console.error('Payment verification error:', err);
    res.status(500).json({ success: false, message: 'Payment verification failed.' });
  }
});

module.exports = router;
