const express = require('express');
const router = express.Router();
const db = require('../db/database');
const config = require('../config');

// POST /api/cart/validate - Validates cart items, prices, and stock
router.post('/validate', (req, res) => {
  try {
    const { items = [] } = req.body;
    let validatedItems = [];
    let subtotal = 0;
    let outOfStockWarnings = [];

    for (const item of items) {
      const product = db.products.findById(item.productId);
      if (!product) continue;

      let sizeObj = (product.sizes || []).find(s => s.size === item.size);
      let availableStock = sizeObj ? sizeObj.stock : (product.stockQuantity || 0);

      let requestedQty = Math.max(1, parseInt(item.quantity, 10) || 1);
      let effectiveQty = Math.min(requestedQty, availableStock);

      if (availableStock === 0) {
        outOfStockWarnings.push(`"${product.name}" (${item.size}) is currently out of stock and removed.`);
        continue;
      } else if (requestedQty > availableStock) {
        outOfStockWarnings.push(`Only ${availableStock} units available for "${product.name}" (${item.size}). Quantity adjusted.`);
      }

      const itemTotal = product.price * effectiveQty;
      subtotal += itemTotal;

      validatedItems.push({
        productId: product.id,
        name: product.name,
        slug: product.slug,
        price: product.price,
        originalPrice: product.originalPrice,
        image: item.image || (product.images && product.images[0]),
        size: item.size || 'Standard',
        color: item.color || (product.colors && product.colors[0]?.name) || 'Pastel',
        quantity: effectiveQty,
        stock: availableStock,
        itemTotal
      });
    }

    const freeShippingThreshold = config.store.freeShippingThreshold;
    const isFreeShipping = subtotal >= freeShippingThreshold || subtotal === 0;
    const shippingFee = isFreeShipping ? 0 : config.store.standardShippingFee;
    const amountToFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

    res.json({
      success: true,
      items: validatedItems,
      subtotal,
      shippingFee,
      freeShippingThreshold,
      isFreeShipping,
      amountToFreeShipping,
      warnings: outOfStockWarnings
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to validate cart.' });
  }
});

// POST /api/cart/apply-coupon
router.post('/apply-coupon', (req, res) => {
  try {
    const { code, subtotal } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: 'Coupon code is required.' });
    }

    const coupon = db.coupons.findOne(c => c.code.toUpperCase() === code.trim().toUpperCase() && c.isActive);
    if (!coupon) {
      return res.status(404).json({ success: false, message: 'Invalid or expired promo code.' });
    }

    const numSubtotal = Number(subtotal) || 0;
    if (coupon.minOrderAmount && numSubtotal < coupon.minOrderAmount) {
      return res.status(400).json({
        success: false,
        message: `This coupon requires a minimum cart value of ₹${coupon.minOrderAmount}.`
      });
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = Math.round((numSubtotal * coupon.discountValue) / 100);
    } else if (coupon.discountType === 'fixed') {
      discount = Math.min(coupon.discountValue, numSubtotal);
    } else if (coupon.discountType === 'shipping') {
      discount = config.store.standardShippingFee;
    }

    res.json({
      success: true,
      message: `Coupon "${coupon.code}" applied successfully!`,
      coupon: {
        code: coupon.code,
        discountType: coupon.discountType,
        discountValue: coupon.discountValue,
        description: coupon.description,
        discountAmount: discount
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to apply coupon.' });
  }
});

module.exports = router;
