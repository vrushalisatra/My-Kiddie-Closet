const db = require('../db/database');

class OrderService {
  /**
   * Generate sequential human-friendly order number e.g. MKC-2026-1002
   */
  generateOrderNumber() {
    const year = new Date().getFullYear();
    const count = db.orders.count();
    const sequence = 1000 + count + 1;
    return `MKC-${year}-${sequence}`;
  }

  /**
   * Generate AWB courier tracking number
   */
  generateTrackingNumber(carrier = 'Delhivery') {
    const prefix = carrier.toUpperCase().substring(0, 3);
    const rand = Math.floor(10000000 + Math.random() * 90000000);
    return `${prefix}-IND-${rand}`;
  }

  /**
   * Deduct product inventory when order is placed
   */
  deductInventory(items) {
    for (const item of items) {
      const product = db.products.findById(item.productId);
      if (product) {
        let updatedStock = Math.max(0, (product.stockQuantity || 0) - item.quantity);
        let updatedSizes = product.sizes ? product.sizes.map(s => {
          if (s.size === item.size) {
            return { ...s, stock: Math.max(0, s.stock - item.quantity) };
          }
          return s;
        }) : [];

        db.products.update(product.id, {
          stockQuantity: updatedStock,
          sizes: updatedSizes,
          inStock: updatedStock > 0
        });
      }
    }
  }

  /**
   * Restore inventory if order is cancelled
   */
  restoreInventory(items) {
    for (const item of items) {
      const product = db.products.findById(item.productId);
      if (product) {
        let updatedStock = (product.stockQuantity || 0) + item.quantity;
        let updatedSizes = product.sizes ? product.sizes.map(s => {
          if (s.size === item.size) {
            return { ...s, stock: s.stock + item.quantity };
          }
          return s;
        }) : [];

        db.products.update(product.id, {
          stockQuantity: updatedStock,
          sizes: updatedSizes,
          inStock: updatedStock > 0
        });
      }
    }
  }
}

module.exports = new OrderService();
