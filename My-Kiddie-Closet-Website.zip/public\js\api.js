/**
 * My Kiddie Closet - Central API Client
 */

const API = {
  baseUrl: '/api',

  getToken() {
    return localStorage.getItem('mkc_token') || '';
  },

  setToken(token) {
    if (token) {
      localStorage.setItem('mkc_token', token);
    } else {
      localStorage.removeItem('mkc_token');
    }
  },

  async request(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `API request failed (${response.status})`);
      }
      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err.message);
      throw err;
    }
  },

  // Auth APIs
  auth: {
    register(payload) {
      return API.request('/auth/register', { method: 'POST', body: JSON.stringify(payload) });
    },
    login(payload) {
      return API.request('/auth/login', { method: 'POST', body: JSON.stringify(payload) });
    },
    me() {
      return API.request('/auth/me');
    },
    updateProfile(payload) {
      return API.request('/auth/profile', { method: 'PUT', body: JSON.stringify(payload) });
    },
    saveAddress(payload) {
      return API.request('/auth/addresses', { method: 'POST', body: JSON.stringify(payload) });
    }
  },

  // Products APIs
  products: {
    list(params = {}) {
      const q = new URLSearchParams(params).toString();
      return API.request(`/products?${q}`);
    },
    getFilters() {
      return API.request('/products/filters');
    },
    getFeatured() {
      return API.request('/products/featured');
    },
    getByIdOrSlug(idOrSlug) {
      return API.request(`/products/${idOrSlug}`);
    },
    addReview(productId, payload) {
      return API.request(`/products/${productId}/reviews`, { method: 'POST', body: JSON.stringify(payload) });
    }
  },

  // Cart & Coupon APIs
  cart: {
    validate(items) {
      return API.request('/cart/validate', { method: 'POST', body: JSON.stringify({ items }) });
    },
    applyCoupon(code, subtotal) {
      return API.request('/cart/apply-coupon', { method: 'POST', body: JSON.stringify({ code, subtotal }) });
    }
  },

  // Wishlist APIs
  wishlist: {
    get() {
      return API.request('/wishlist');
    },
    toggle(productId) {
      return API.request('/wishlist/toggle', { method: 'POST', body: JSON.stringify({ productId }) });
    },
    sync(productIds) {
      return API.request('/wishlist/sync', { method: 'POST', body: JSON.stringify({ productIds }) });
    }
  },

  // Order APIs
  orders: {
    create(orderPayload) {
      return API.request('/orders', { method: 'POST', body: JSON.stringify(orderPayload) });
    },
    myOrders() {
      return API.request('/orders/my-orders');
    },
    track(orderNumberOrId) {
      return API.request(`/orders/track/${encodeURIComponent(orderNumberOrId)}`);
    },
    getById(id) {
      return API.request(`/orders/${id}`);
    }
  },

  // Payment APIs
  payments: {
    createRazorpayOrder(amount, receipt, notes) {
      return API.request('/payments/razorpay/create-order', {
        method: 'POST',
        body: JSON.stringify({ amount, receipt, notes })
      });
    },
    verifyPayment(payload) {
      return API.request('/payments/razorpay/verify-payment', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    }
  },

  // Admin APIs
  admin: {
    getStats() {
      return API.request('/admin/stats');
    },
    getProducts() {
      return API.request('/admin/products');
    },
    createProduct(payload) {
      return API.request('/admin/products', { method: 'POST', body: JSON.stringify(payload) });
    },
    updateProduct(id, payload) {
      return API.request(`/admin/products/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
    },
    deleteProduct(id) {
      return API.request(`/admin/products/${id}`, { method: 'DELETE' });
    },
    updateStock(id, stockQuantity) {
      return API.request(`/admin/products/${id}/stock`, { method: 'PATCH', body: JSON.stringify({ stockQuantity }) });
    },
    getOrders(status) {
      const q = status ? `?status=${status}` : '';
      return API.request(`/admin/orders${q}`);
    },
    updateOrderStatus(orderId, payload) {
      return API.request(`/admin/orders/${orderId}/status`, { method: 'PATCH', body: JSON.stringify(payload) });
    },
    getCustomers() {
      return API.request('/admin/customers');
    },
    getSettings() {
      return API.request('/admin/settings');
    },
    updateSettings(payload) {
      return API.request('/admin/settings', { method: 'PUT', body: JSON.stringify(payload) });
    }
  }
};

window.API = API;
