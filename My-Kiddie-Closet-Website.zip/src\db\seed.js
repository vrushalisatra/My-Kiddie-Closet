const bcrypt = require('bcryptjs');
const db = require('./database');

async function seedDatabase() {
  console.log('Seeding database for My Kiddie Closet...');

  // 1. Seed Users (Admin + Demo Customer)
  if (db.users.count() === 0) {
    const adminPasswordHash = await bcrypt.hash('admin123', 10);
    const parentPasswordHash = await bcrypt.hash('parent123', 10);

    db.users.insertMany([
      {
        id: 'user_admin_01',
        name: 'MKC Admin',
        email: 'admin@mykiddiecloset.com',
        password: adminPasswordHash,
        role: 'admin',
        phone: '+91 98765 43210',
        addresses: [
          {
            id: 'addr_hq',
            isDefault: true,
            fullName: 'My Kiddie Closet HQ',
            phone: '+91 98765 43210',
            addressLine1: 'Plot 42, Lotus Tech Park, Andheri East',
            addressLine2: 'Near Western Express Highway',
            city: 'Mumbai',
            state: 'Maharashtra',
            pincode: '400069',
            landmark: 'Opposite Metro Station'
          }
        ]
      },
      {
        id: 'user_priya_01',
        name: 'Priya Sharma',
        email: 'priya@example.com',
        password: parentPasswordHash,
        role: 'customer',
        phone: '+91 98200 11223',
        addresses: [
          {
            id: 'addr_priya_home',
            isDefault: true,
            fullName: 'Priya Sharma',
            phone: '+91 98200 11223',
            addressLine1: 'Flat 702, Magnolia Towers',
            addressLine2: 'Hiranandani Estate, Ghodbunder Road',
            city: 'Thane',
            state: 'Maharashtra',
            pincode: '400607',
            landmark: 'Near Club House'
          }
        ]
      }
    ]);
    console.log('  -> Users seeded.');
  }

  // 2. Seed Products
  if (db.products.count() === 0) {
    const productsData = [
      // Baby & Toddler
      {
        id: 'prod_baby_01',
        name: 'Pastel Dream Organic Cotton Kimono Sleepsuit',
        slug: 'pastel-dream-organic-cotton-kimono-sleepsuit',
        tagline: 'Ultra-soft wrap style for peaceful naps and quick midnight changes',
        description: 'Crafted from 100% GOTS-certified organic Peruvian Pima cotton. Features an easy side-snap kimono design that avoids pulling over delicate newborn heads, with fold-over scratch mittens on sizes up to 6 months.',
        collection: 'baby-toddler',
        category: 'Sleepwear & Rompers',
        ageGroup: '0-6M',
        price: 899,
        originalPrice: 1299,
        discountPercent: 31,
        featured: true,
        bestseller: true,
        isNew: true,
        rating: 4.9,
        reviewCount: 38,
        inStock: true,
        stockQuantity: 45,
        sizes: [
          { size: 'Newborn', stock: 10 },
          { size: '0-3M', stock: 15 },
          { size: '3-6M', stock: 12 },
          { size: '6-12M', stock: 8 }
        ],
        colors: [
          { name: 'Baby Pink', hex: '#FAD2E1', imageIdx: 0 },
          { name: 'Baby Blue', hex: '#C5DFF8', imageIdx: 1 },
          { name: 'Cloud White', hex: '#FBFBFB', imageIdx: 2 }
        ],
        images: [
          'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% GOTS Organic Combed Cotton, Nickel-Free Snaps',
        careInstructions: 'Machine wash gentle cold (30°C). Do not bleach. Tumble dry low.',
        sku: 'MKC-BT-001'
      },
      {
        id: 'prod_baby_02',
        name: 'Cloud Waffle Knit Jumpsuit & Bonnet Set',
        slug: 'cloud-waffle-knit-jumpsuit-bonnet-set',
        tagline: 'Cozy waffle texture with matching sweet ear bonnet',
        description: 'A luxurious heirloom-quality 2-piece set. Pure breathable waffle knit cotton with natural wooden buttons along the front and convenient crotch snaps for effortless diaper changes.',
        collection: 'baby-toddler',
        category: 'Sets & Suits',
        ageGroup: '6-12M',
        price: 1199,
        originalPrice: 1699,
        discountPercent: 29,
        featured: true,
        bestseller: true,
        isNew: false,
        rating: 4.8,
        reviewCount: 29,
        inStock: true,
        stockQuantity: 32,
        sizes: [
          { size: '0-3M', stock: 6 },
          { size: '3-6M', stock: 10 },
          { size: '6-12M', stock: 9 },
          { size: '1-2Y', stock: 7 }
        ],
        colors: [
          { name: 'Soft Sage', hex: '#D8E2DC', imageIdx: 0 },
          { name: 'Baby Blue', hex: '#BEE3F8', imageIdx: 1 },
          { name: 'Warm Cream', hex: '#FAF0CA', imageIdx: 2 }
        ],
        images: [
          'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Breathable Waffle Cotton Knit',
        careInstructions: 'Hand wash or delicate machine wash cold. Dry flat in shade.',
        sku: 'MKC-BT-002'
      },
      {
        id: 'prod_baby_03',
        name: 'Smiling Safari Baby Cotton Bodysuit (Pack of 3)',
        slug: 'smiling-safari-baby-cotton-bodysuit-pack',
        tagline: 'Joyful animal prints designed to keep baby cheerful all day',
        description: 'Everyday essentials made extraordinary. Trio of buttery soft bodysuits with expandable lap-neck shoulders for easy dressing up or down, and reinforced snap closures.',
        collection: 'baby-toddler',
        category: 'Bodysuits',
        ageGroup: '0-6M',
        price: 999,
        originalPrice: 1399,
        discountPercent: 28,
        featured: false,
        bestseller: true,
        isNew: true,
        rating: 4.9,
        reviewCount: 54,
        inStock: true,
        stockQuantity: 60,
        sizes: [
          { size: '0-3M', stock: 18 },
          { size: '3-6M', stock: 22 },
          { size: '6-12M', stock: 20 }
        ],
        colors: [
          { name: 'Baby Blue Safari', hex: '#A0D2EB', imageIdx: 0 },
          { name: 'Pastel Yellow Elephant', hex: '#FFF1C5', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Hypoallergenic Cotton with Non-toxic Dyes',
        careInstructions: 'Machine washable, color-safe.',
        sku: 'MKC-BT-003'
      },
      {
        id: 'prod_baby_04',
        name: 'Cozy Bear Hooded Fleece Romper with Ears',
        slug: 'cozy-bear-hooded-fleece-romper',
        tagline: 'Keep your little adventurer warm and snug as a cuddly bear',
        description: 'Crafted with premium sherpa fleece on the exterior and lined with 100% organic cotton jersey against delicate skin. Full-length dual diagonal zipper for swift changes without undressing.',
        collection: 'baby-toddler',
        category: 'Sleepwear & Rompers',
        ageGroup: '6-12M',
        price: 1349,
        originalPrice: 1899,
        discountPercent: 29,
        featured: true,
        bestseller: false,
        isNew: true,
        rating: 4.9,
        reviewCount: 22,
        inStock: true,
        stockQuantity: 28,
        sizes: [
          { size: '3-6M', stock: 8 },
          { size: '6-12M', stock: 10 },
          { size: '1-2Y', stock: 10 }
        ],
        colors: [
          { name: 'Baby Pink', hex: '#FFD1DC', imageIdx: 0 },
          { name: 'Baby Blue', hex: '#BEE3F8', imageIdx: 1 },
          { name: 'Teddy Brown', hex: '#D4A373', imageIdx: 2 }
        ],
        images: [
          'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: 'Outer: Ultra-soft Sherpa Fleece; Lining: 100% Organic Cotton',
        careInstructions: 'Gentle machine wash cold. Hang dry.',
        sku: 'MKC-BT-004'
      },
      {
        id: 'prod_baby_05',
        name: 'Pastel Ribbed Dungaree & Tee Twin Set',
        slug: 'pastel-ribbed-dungaree-tee-twin-set',
        tagline: 'Vintage charm meets everyday playful playground comfort',
        description: 'Features adjustable strap overall dungarees made from soft stretch corduroy and a pure cotton striped tee. Cross-back suspender straps with double button adjustments for growing babies.',
        collection: 'baby-toddler',
        category: 'Sets & Suits',
        ageGroup: '1-2Y',
        price: 1249,
        originalPrice: 1799,
        discountPercent: 30,
        featured: false,
        bestseller: true,
        isNew: false,
        rating: 4.7,
        reviewCount: 19,
        inStock: true,
        stockQuantity: 25,
        sizes: [
          { size: '6-12M', stock: 8 },
          { size: '1-2Y', stock: 10 },
          { size: '2-3Y', stock: 7 }
        ],
        colors: [
          { name: 'Dusty Blue', hex: '#90CAF9', imageIdx: 0 },
          { name: 'Rose Bloom', hex: '#F48FB1', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: 'Soft Cotton Corduroy & 100% Cotton Rib Tee',
        careInstructions: 'Machine wash warm, tumble dry normal.',
        sku: 'MKC-BT-005'
      },

      // Girls Collection
      {
        id: 'prod_girls_01',
        name: 'Enchanted Blossom Twirl Cotton Frock',
        slug: 'enchanted-blossom-twirl-cotton-frock',
        tagline: 'A dream for little dancers with 360-degree flare and delicate hand-painted floras',
        description: 'Made for celebrations, garden strolls, and joyous birthdays! Premium combed cotton sateen featuring sweet flutter sleeve accents, a gentle cotton voile lining, and an invisible back zipper with a soft inner flap to protect tender skin.',
        collection: 'girls',
        category: 'Dresses & Frocks',
        ageGroup: '2-4Y',
        price: 1499,
        originalPrice: 2199,
        discountPercent: 32,
        featured: true,
        bestseller: true,
        isNew: true,
        rating: 4.9,
        reviewCount: 47,
        inStock: true,
        stockQuantity: 35,
        sizes: [
          { size: '1-2Y', stock: 8 },
          { size: '2-3Y', stock: 10 },
          { size: '3-4Y', stock: 10 },
          { size: '4-5Y', stock: 7 }
        ],
        colors: [
          { name: 'Pastel Baby Pink', hex: '#FAD2E1', imageIdx: 0 },
          { name: 'Hydrangea Blue', hex: '#C5DFF8', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Breathable Cotton Sateen with 100% Cotton Voile Lining',
        careInstructions: 'Gentle hand wash or delicate cycle. Iron on reverse.',
        sku: 'MKC-G-001'
      },
      {
        id: 'prod_girls_02',
        name: 'Starlight Tulle Birthday Party Dress',
        slug: 'starlight-tulle-birthday-party-dress',
        tagline: 'Shimmering metallic star accents on cloud-soft tulle',
        description: 'Turn special moments into magical memories. Multi-layered non-scratch soft tulle over a gentle 100% cotton slip. Finished with an elegant satin sash bow at the back and flutter butterfly cap sleeves.',
        collection: 'girls',
        category: 'Dresses & Frocks',
        ageGroup: '4-6Y',
        price: 1899,
        originalPrice: 2699,
        discountPercent: 30,
        featured: true,
        bestseller: false,
        isNew: true,
        rating: 5.0,
        reviewCount: 31,
        inStock: true,
        stockQuantity: 24,
        sizes: [
          { size: '2-3Y', stock: 6 },
          { size: '3-4Y', stock: 8 },
          { size: '4-5Y', stock: 6 },
          { size: '5-6Y', stock: 4 }
        ],
        colors: [
          { name: 'Baby Pink Shimmer', hex: '#F8BBD0', imageIdx: 0 },
          { name: 'Cloud Blue Sparkle', hex: '#B3E5FC', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: 'Feather-soft Nylon Tulle with 100% Pure Cotton Underlay',
        careInstructions: 'Gentle hand wash in cold water. Do not wring.',
        sku: 'MKC-G-002'
      },
      {
        id: 'prod_girls_03',
        name: 'Sweet Lavender Meadow Cotton Ruffle Set',
        slug: 'sweet-lavender-meadow-cotton-ruffle-set',
        tagline: 'Playtime elegance with breezy ruffles and comfortable bloomer shorts',
        description: 'A charming 2-piece ensemble crafted from soft lightweight seersucker cotton. Includes a square-neck smocked peplum blouse and matching bloomer shorts with gentle non-pinching elastic waistbands.',
        collection: 'girls',
        category: 'Sets & Suits',
        ageGroup: '1-2Y',
        price: 1099,
        originalPrice: 1599,
        discountPercent: 31,
        featured: false,
        bestseller: true,
        isNew: false,
        rating: 4.8,
        reviewCount: 26,
        inStock: true,
        stockQuantity: 30,
        sizes: [
          { size: '1-2Y', stock: 10 },
          { size: '2-3Y', stock: 10 },
          { size: '3-4Y', stock: 10 }
        ],
        colors: [
          { name: 'Soft Lavender', hex: '#E1BEE7', imageIdx: 0 },
          { name: 'Baby Pink', hex: '#FAD2E1', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Breathable Cotton Seersucker',
        careInstructions: 'Machine wash cold with like colors.',
        sku: 'MKC-G-003'
      },
      {
        id: 'prod_girls_04',
        name: 'Butterflies & Rainbows Organic Sleep Pajama Set',
        slug: 'butterflies-rainbows-organic-pajama-set',
        tagline: 'Cozy snug-fit 2-piece pajamas for sweet dreams',
        description: 'Certified 100% organic rib cotton pajamas that stretch with your toddler. Features ribbed ankle and wrist cuffs that prevent bunching up during active night movements and an enclosed elastic waistband.',
        collection: 'girls',
        category: 'Sleepwear & Rompers',
        ageGroup: '2-4Y',
        price: 849,
        originalPrice: 1199,
        discountPercent: 29,
        featured: false,
        bestseller: false,
        isNew: true,
        rating: 4.9,
        reviewCount: 33,
        inStock: true,
        stockQuantity: 40,
        sizes: [
          { size: '1-2Y', stock: 10 },
          { size: '2-3Y', stock: 15 },
          { size: '3-4Y', stock: 10 },
          { size: '4-5Y', stock: 5 }
        ],
        colors: [
          { name: 'Baby Pink Butterfy', hex: '#FFD1DC', imageIdx: 0 },
          { name: 'Sky Cloud', hex: '#E1F5FE', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% GOTS Organic Ribbed Cotton',
        careInstructions: 'Machine wash warm, tumble dry medium.',
        sku: 'MKC-G-004'
      },
      {
        id: 'prod_girls_05',
        name: 'Sunny Day Daisy Embroidered Denim Pinafore',
        slug: 'sunny-day-daisy-embroidered-denim-pinafore',
        tagline: 'Charming vintage denim with hand-embroidered daisies and roomy front pockets',
        description: 'Made from supple washed cotton denim that is soft and durable. Looks darling paired over blouses, t-shirts, or knit sweaters for year-round layering.',
        collection: 'girls',
        category: 'Dresses & Frocks',
        ageGroup: '2-4Y',
        price: 1299,
        originalPrice: 1799,
        discountPercent: 28,
        featured: false,
        bestseller: true,
        isNew: false,
        rating: 4.7,
        reviewCount: 18,
        inStock: true,
        stockQuantity: 20,
        sizes: [
          { size: '1-2Y', stock: 6 },
          { size: '2-3Y', stock: 8 },
          { size: '3-4Y', stock: 6 }
        ],
        colors: [
          { name: 'Baby Blue Denim', hex: '#89CFF0', imageIdx: 0 }
        ],
        images: [
          'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Washed Soft Cotton Denim',
        careInstructions: 'Machine wash inside out. Tumble dry normal.',
        sku: 'MKC-G-005'
      },

      // Boys Collection
      {
        id: 'prod_boys_01',
        name: 'Little Gentleman Linen Shirt & Suspenders Set',
        slug: 'little-gentleman-linen-shirt-suspenders-set',
        tagline: 'Smart formal look with all the comfort your active boy needs',
        description: 'A 3-piece showstopper! Includes a mandarin collar breathable linen-cotton shirt, soft twill chino shorts with adjustable inner waistband elastic, and detachable faux-leather clip-on suspenders.',
        collection: 'boys',
        category: 'Sets & Suits',
        ageGroup: '2-4Y',
        price: 1699,
        originalPrice: 2499,
        discountPercent: 32,
        featured: true,
        bestseller: true,
        isNew: true,
        rating: 4.9,
        reviewCount: 42,
        inStock: true,
        stockQuantity: 38,
        sizes: [
          { size: '1-2Y', stock: 8 },
          { size: '2-3Y', stock: 12 },
          { size: '3-4Y', stock: 10 },
          { size: '4-5Y', stock: 8 }
        ],
        colors: [
          { name: 'Baby Blue & Khaki', hex: '#A0D2EB', imageIdx: 0 },
          { name: 'Pastel Blush & Navy', hex: '#FAD2E1', imageIdx: 1 },
          { name: 'Pure White & Beige', hex: '#F8F9FA', imageIdx: 2 }
        ],
        images: [
          'https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1503945438517-f65904a52ce6?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1471286174890-9c112ffca56a?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '55% Organic Linen, 45% Combed Cotton Shirt; 100% Cotton Chino Shorts',
        careInstructions: 'Machine wash cold gentle. Medium iron.',
        sku: 'MKC-B-001'
      },
      {
        id: 'prod_boys_02',
        name: 'Dino Explorer Organic Cotton Henley & Jogger Set',
        slug: 'dino-explorer-organic-cotton-henley-jogger-set',
        tagline: 'Playground ready with fun embossed dinosaurs and reinforced knees',
        description: 'Designed for boys who love to explore, climb, and run! Two-piece set made from heavy 240 GSM organic french terry cotton with reinforced knee patches, stretchy rib cuffs, and functional drawstring.',
        collection: 'boys',
        category: 'Sets & Suits',
        ageGroup: '2-4Y',
        price: 1299,
        originalPrice: 1799,
        discountPercent: 28,
        featured: true,
        bestseller: true,
        isNew: false,
        rating: 4.8,
        reviewCount: 35,
        inStock: true,
        stockQuantity: 44,
        sizes: [
          { size: '1-2Y', stock: 10 },
          { size: '2-3Y', stock: 14 },
          { size: '3-4Y', stock: 12 },
          { size: '4-5Y', stock: 8 }
        ],
        colors: [
          { name: 'Baby Sky Blue', hex: '#BEE3F8', imageIdx: 0 },
          { name: 'Sage Dino Green', hex: '#C7D9C7', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1503945438517-f65904a52ce6?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% GOTS Certified Organic French Terry Cotton',
        careInstructions: 'Machine wash warm, tumble dry low.',
        sku: 'MKC-B-002'
      },
      {
        id: 'prod_boys_03',
        name: 'Seaside Sailor Striped Polo T-Shirt',
        slug: 'seaside-sailor-striped-polo-t-shirt',
        tagline: 'Crisp classic nautical stripes with soft knit collar',
        description: 'Every little boy needs a dependable, handsome polo. Features pique knit organic cotton, breathable side vents, wood-finish buttons, and our signature playful embroidered elephant crest on the chest.',
        collection: 'boys',
        category: 'T-Shirts & Tops',
        ageGroup: '4-6Y',
        price: 799,
        originalPrice: 1199,
        discountPercent: 33,
        featured: false,
        bestseller: false,
        isNew: true,
        rating: 4.7,
        reviewCount: 16,
        inStock: true,
        stockQuantity: 50,
        sizes: [
          { size: '2-3Y', stock: 12 },
          { size: '3-4Y', stock: 15 },
          { size: '4-5Y', stock: 13 },
          { size: '5-6Y', stock: 10 }
        ],
        colors: [
          { name: 'Baby Blue / White Stripe', hex: '#89CFF0', imageIdx: 0 },
          { name: 'Pastel Pink / White Stripe', hex: '#FAD2E1', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1471286174890-9c112ffca56a?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Combed Pique Cotton',
        careInstructions: 'Machine wash cold with like colors.',
        sku: 'MKC-B-003'
      },
      {
        id: 'prod_boys_04',
        name: 'Safari Sunset Camp Collar Cuban Shirt',
        slug: 'safari-sunset-camp-collar-cuban-shirt',
        tagline: 'Relaxed resort style for summer holidays and family vacations',
        description: 'Featherlight rayon-cotton blend shirt with an open camp collar and hand-drawn illustrated safari animals. Keeps your little one cool even on the warmest sunny days.',
        collection: 'boys',
        category: 'T-Shirts & Tops',
        ageGroup: '2-4Y',
        price: 899,
        originalPrice: 1299,
        discountPercent: 31,
        featured: false,
        bestseller: true,
        isNew: false,
        rating: 4.8,
        reviewCount: 27,
        inStock: true,
        stockQuantity: 36,
        sizes: [
          { size: '1-2Y', stock: 8 },
          { size: '2-3Y', stock: 10 },
          { size: '3-4Y', stock: 10 },
          { size: '4-5Y', stock: 8 }
        ],
        colors: [
          { name: 'Pastel Sky', hex: '#BEE3F8', imageIdx: 0 },
          { name: 'Sunny Peach', hex: '#FFE5D9', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1503945438517-f65904a52ce6?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1471286174890-9c112ffca56a?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '60% Soft Cotton, 40% Breathable Rayon',
        careInstructions: 'Gentle machine wash cold. Low iron.',
        sku: 'MKC-B-004'
      },
      {
        id: 'prod_boys_05',
        name: 'Cloud Soft Stretch Denim Shorts',
        slug: 'cloud-soft-stretch-denim-shorts',
        tagline: 'The look of authentic denim with the softness of lounge pajamas',
        description: 'Woven with four-way stretch yarn and pre-washed with hypoallergenic fabric softener. Features a fully elasticated ribbed knit waistband with adjustable drawcord and rolled cuffs.',
        collection: 'boys',
        category: 'Bottoms & Shorts',
        ageGroup: '2-4Y',
        price: 749,
        originalPrice: 1099,
        discountPercent: 32,
        featured: false,
        bestseller: false,
        isNew: false,
        rating: 4.6,
        reviewCount: 14,
        inStock: true,
        stockQuantity: 40,
        sizes: [
          { size: '1-2Y', stock: 10 },
          { size: '2-3Y', stock: 12 },
          { size: '3-4Y', stock: 10 },
          { size: '4-5Y', stock: 8 }
        ],
        colors: [
          { name: 'Light Baby Blue Wash', hex: '#90CAF9', imageIdx: 0 },
          { name: 'Medium Indigo', hex: '#64B5F6', imageIdx: 1 }
        ],
        images: [
          'https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '98% Cotton, 2% Spandex Ultra-flex Denim',
        careInstructions: 'Machine wash warm inside out.',
        sku: 'MKC-B-005'
      },

      // Accessories
      {
        id: 'prod_acc_01',
        name: 'Little Steps First Walker Soft-Sole Leather Shoes',
        slug: 'little-steps-first-walker-soft-sole-leather-shoes',
        tagline: 'Pediatrician-approved flexible suede sole for natural foot development',
        description: 'Handcrafted from butter-soft genuine breathable leather with non-slip textured suede soles. Elasticized collar guarantees they stay snug on active kicking baby feet without pinching.',
        collection: 'baby-toddler',
        category: 'Accessories & Shoes',
        ageGroup: '0-6M',
        price: 799,
        originalPrice: 1199,
        discountPercent: 33,
        featured: false,
        bestseller: true,
        isNew: true,
        rating: 4.9,
        reviewCount: 28,
        inStock: true,
        stockQuantity: 30,
        sizes: [
          { size: '0-6M', stock: 10 },
          { size: '6-12M', stock: 10 },
          { size: '12-18M', stock: 10 }
        ],
        colors: [
          { name: 'Baby Pink', hex: '#FAD2E1', imageIdx: 0 },
          { name: 'Baby Blue', hex: '#BEE3F8', imageIdx: 1 },
          { name: 'Soft Cream', hex: '#FFF1E6', imageIdx: 2 }
        ],
        images: [
          'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '100% Genuine Chrome-Free Soft Leather & Suede',
        careInstructions: 'Wipe clean with a damp cloth.',
        sku: 'MKC-AC-001'
      },
      {
        id: 'prod_acc_02',
        name: 'Organic Muslin Swaddle Blankets (Set of 3)',
        slug: 'organic-muslin-swaddle-blankets-set-of-3',
        tagline: 'GOTS certified cloud softness that gets softer with every wash',
        description: 'Extra-large 120 x 120 cm swaddles crafted from four layers of open-weave organic bamboo-cotton muslin. Versatile as swaddle wrap, nursing shield, stroller sun cover, or tummy-time play mat.',
        collection: 'baby-toddler',
        category: 'Accessories & Shoes',
        ageGroup: '0-6M',
        price: 1199,
        originalPrice: 1699,
        discountPercent: 29,
        featured: true,
        bestseller: true,
        isNew: false,
        rating: 5.0,
        reviewCount: 65,
        inStock: true,
        stockQuantity: 50,
        sizes: [
          { size: 'One Size (120x120cm)', stock: 50 }
        ],
        colors: [
          { name: 'Pastel Dream Trio (Pink/Blue/Cream)', hex: '#FAD2E1', imageIdx: 0 }
        ],
        images: [
          'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80'
        ],
        fabric: '70% Organic Bamboo, 30% GOTS Organic Cotton',
        careInstructions: 'Machine wash warm, tumble dry low for crinkly softness.',
        sku: 'MKC-AC-002'
      }
    ];

    db.products.insertMany(productsData);
    console.log(`  -> ${productsData.length} Products seeded.`);
  }

  // 3. Seed Coupons
  if (db.coupons.count() === 0) {
    db.coupons.insertMany([
      {
        id: 'cpn_little10',
        code: 'LITTLE10',
        discountType: 'percentage',
        discountValue: 10,
        minOrderAmount: 499,
        description: '10% discount on all orders above ₹499',
        isActive: true
      },
      {
        id: 'cpn_welcome15',
        code: 'WELCOME15',
        discountType: 'percentage',
        discountValue: 15,
        minOrderAmount: 999,
        description: '15% welcome discount for new parents',
        isActive: true
      },
      {
        id: 'cpn_freeship',
        code: 'FREESHIP',
        discountType: 'shipping',
        discountValue: 100,
        minOrderAmount: 0,
        description: 'Free Express Shipping on your order',
        isActive: true
      },
      {
        id: 'cpn_kiddie500',
        code: 'KIDDIE500',
        discountType: 'fixed',
        discountValue: 500,
        minOrderAmount: 2499,
        description: 'Flat ₹500 off on shopping above ₹2,499',
        isActive: true
      }
    ]);
    console.log('  -> Coupons seeded.');
  }

  // 4. Seed Orders for Demo Customer (with tracking milestones)
  if (db.orders.count() === 0) {
    db.orders.insertMany([
      {
        id: 'ord_mkc_1001',
        orderNumber: 'MKC-2026-1001',
        userId: 'user_priya_01',
        customerName: 'Priya Sharma',
        customerEmail: 'priya@example.com',
        customerPhone: '+91 98200 11223',
        status: 'In Transit', // Placed, Confirmed, Shipped, In Transit, Out for Delivery, Delivered
        shippingMethod: 'Express Courier',
        trackingNumber: 'DEL-IND-882391024',
        courierPartner: 'Delhivery Express',
        paymentMethod: 'Razorpay Online',
        paymentStatus: 'Paid',
        razorpayPaymentId: 'pay_N9k8xY10mQz',
        subtotal: 2398,
        discount: 240,
        couponCode: 'LITTLE10',
        shippingFee: 0,
        tax: 0,
        total: 2158,
        shippingAddress: {
          fullName: 'Priya Sharma',
          phone: '+91 98200 11223',
          addressLine1: 'Flat 702, Magnolia Towers',
          addressLine2: 'Hiranandani Estate, Ghodbunder Road',
          city: 'Thane',
          state: 'Maharashtra',
          pincode: '400607',
          landmark: 'Near Club House'
        },
        items: [
          {
            productId: 'prod_baby_01',
            name: 'Pastel Dream Organic Cotton Kimono Sleepsuit',
            price: 899,
            quantity: 1,
            size: '0-3M',
            color: 'Baby Pink',
            image: 'https://images.unsplash.com/photo-1522771930-78848d9293e8?auto=format&fit=crop&w=800&q=80'
          },
          {
            productId: 'prod_girls_01',
            name: 'Enchanted Blossom Twirl Cotton Frock',
            price: 1499,
            quantity: 1,
            size: '2-3Y',
            color: 'Pastel Baby Pink',
            image: 'https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?auto=format&fit=crop&w=800&q=80'
          }
        ],
        timeline: [
          { status: 'Order Placed', timestamp: '2026-11-13T10:30:00.000Z', note: 'Payment verified via Razorpay' },
          { status: 'Quality Inspected & Packed', timestamp: '2026-11-13T14:15:00.000Z', note: 'Carefully wrapped in signature tissue & keepsake box' },
          { status: 'Dispatched from Mumbai Hub', timestamp: '2026-11-14T09:00:00.000Z', note: 'Handed over to Delhivery Express (AWB: DEL-IND-882391024)' },
          { status: 'In Transit', timestamp: '2026-11-14T18:40:00.000Z', note: 'Arrived at regional delivery hub - Thane North' }
        ],
        estimatedDelivery: '2026-11-16'
      },
      {
        id: 'ord_mkc_1000',
        orderNumber: 'MKC-2026-1000',
        userId: 'user_priya_01',
        customerName: 'Priya Sharma',
        customerEmail: 'priya@example.com',
        customerPhone: '+91 98200 11223',
        status: 'Delivered',
        shippingMethod: 'Standard Delivery',
        trackingNumber: 'BLUEDART-7729104',
        courierPartner: 'BlueDart Air',
        paymentMethod: 'Cash on Delivery',
        paymentStatus: 'Paid',
        subtotal: 1699,
        discount: 0,
        couponCode: null,
        shippingFee: 0,
        tax: 0,
        total: 1699,
        shippingAddress: {
          fullName: 'Priya Sharma',
          phone: '+91 98200 11223',
          addressLine1: 'Flat 702, Magnolia Towers',
          addressLine2: 'Hiranandani Estate, Ghodbunder Road',
          city: 'Thane',
          state: 'Maharashtra',
          pincode: '400607',
          landmark: 'Near Club House'
        },
        items: [
          {
            productId: 'prod_boys_01',
            name: 'Little Gentleman Linen Shirt & Suspenders Set',
            price: 1699,
            quantity: 1,
            size: '2-3Y',
            color: 'Baby Blue & Khaki',
            image: 'https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=800&q=80'
          }
        ],
        timeline: [
          { status: 'Order Placed', timestamp: '2026-11-05T11:20:00.000Z', note: 'COD order confirmed via SMS' },
          { status: 'Packed', timestamp: '2026-11-05T16:00:00.000Z', note: 'Ready for dispatch' },
          { status: 'Shipped', timestamp: '2026-11-06T10:00:00.000Z', note: 'Handed over to BlueDart' },
          { status: 'Out for Delivery', timestamp: '2026-11-07T08:30:00.000Z', note: 'Courier agent on route to address' },
          { status: 'Delivered', timestamp: '2026-11-07T14:10:00.000Z', note: 'Delivered to resident and signed' }
        ],
        deliveredAt: '2026-11-07T14:10:00.000Z'
      }
    ]);
    console.log('  -> Demo Orders seeded.');
  }

  // 5. Seed Reviews
  if (db.reviews.count() === 0) {
    db.reviews.insertMany([
      {
        id: 'rev_01',
        productId: 'prod_baby_01',
        userName: 'Aanya Mehta',
        userCity: 'Bengaluru',
        rating: 5,
        title: 'Beyond soft! Perfect for my newborn',
        comment: 'The kimono style is a lifesaver. No awkward slipping over newborn head! The cotton feels like a cloud and survived numerous washes without shrinking. My baby sleeps so peacefully in it.',
        verifiedPurchase: true,
        createdAt: '2026-11-10T12:00:00.000Z'
      },
      {
        id: 'rev_02',
        productId: 'prod_baby_01',
        userName: 'Rohit Verma',
        userCity: 'Delhi NCR',
        rating: 5,
        title: 'Great quality, lovely baby pastel shades',
        comment: 'Ordered both the baby pink and baby blue colors. The packaging was immaculate with cute handwritten note. Will definitely buy again!',
        verifiedPurchase: true,
        createdAt: '2026-11-08T15:30:00.000Z'
      },
      {
        id: 'rev_03',
        productId: 'prod_girls_01',
        userName: 'Sneha Patel',
        userCity: 'Ahmedabad',
        rating: 5,
        title: 'My 3-year-old would not take this off!',
        comment: 'The twirl factor is 10/10! The lining is super soft cotton, zero scratchiness. She wore it for her cousin birthday party and got endless compliments.',
        verifiedPurchase: true,
        createdAt: '2026-11-09T09:15:00.000Z'
      },
      {
        id: 'rev_04',
        productId: 'prod_boys_01',
        userName: 'Vikram Sengupta',
        userCity: 'Kolkata',
        rating: 5,
        title: 'Outstanding quality and fit',
        comment: 'The linen fabric is top-notch and the suspenders are detachable which makes washing easy. Looked dapper in photos!',
        verifiedPurchase: true,
        createdAt: '2026-11-06T18:20:00.000Z'
      }
    ]);
    console.log('  -> Reviews seeded.');
  }

  // 6. Seed Wishlists
  if (db.wishlists.count() === 0) {
    db.wishlists.insertMany([
      {
        id: 'wl_priya_01',
        userId: 'user_priya_01',
        productIds: ['prod_baby_02', 'prod_girls_02', 'prod_acc_02']
      }
    ]);
    console.log('  -> Wishlists seeded.');
  }

  // 7. Store Settings
  if (db.settings.count() === 0) {
    db.settings.insert({
      id: 'store_settings',
      brandName: 'My Kiddie Closet',
      tagline: 'Little Looks for Big Imaginations',
      primaryColorPink: '#F4C2C2',
      primaryColorBlue: '#89CFF0',
      currency: 'INR',
      currencySymbol: '₹',
      freeShippingThreshold: 999,
      standardShippingFee: 99,
      expressShippingFee: 199,
      contactEmail: 'care@mykiddiecloset.com',
      contactPhone: '+91 98765 43210',
      whatsappNumber: '+919876543210',
      address: 'Plot 42, Lotus Tech Park, Andheri East, Mumbai, Maharashtra 400069, India',
      razorpayKeyId: process.env.RAZORPAY_KEY_ID || 'rzp_test_MKCdemo99182',
      razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || 'mkc_test_secret_demo_982'
    });
    console.log('  -> Store Settings initialized.');
  }

  console.log('Database seeding complete!\n');
}

module.exports = { seedDatabase };

if (require.main === module) {
  seedDatabase();
}
