require('dotenv').config();

module.exports = {
  port: process.env.PORT || 5000,
  jwtSecret: process.env.JWT_SECRET || 'my_kiddie_closet_super_secure_jwt_secret_2026',
  razorpay: {
    keyId: process.env.RAZORPAY_KEY_ID || 'rzp_test_MKCdemo99182',
    keySecret: process.env.RAZORPAY_KEY_SECRET || 'mkc_test_secret_demo_982',
    mockMode: process.env.RAZORPAY_MOCK_MODE !== 'false' // default true if test keys
  },
  store: {
    name: 'My Kiddie Closet',
    tagline: 'Little Looks for Big Imaginations',
    currency: 'INR',
    currencySymbol: '₹',
    freeShippingThreshold: 999,
    standardShippingFee: 99,
    expressShippingFee: 199
  }
};
